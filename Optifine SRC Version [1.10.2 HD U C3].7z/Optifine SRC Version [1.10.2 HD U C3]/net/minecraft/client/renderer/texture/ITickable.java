package net.minecraft.client.renderer.texture;

public interface ITickable
{
    void tick();
}
