package net.optifine.render;

import java.util.Random;
import net.minecraft.util.math.vector.Matrix3f;
import net.minecraft.util.math.vector.Matrix4f;
import net.minecraft.util.math.vector.Quaternion;
import net.minecraft.util.math.vector.Vec3f;
import net.minecraft.util.math.vector.Vec4f;

public class TestMath
{
    static Random random = new Random();

    public static void main(String[] args)
    {
        int i = 1000000;
        dbg("Test math: " + i);

        for (int j = 0; j < 1000000; ++j)
        {
            testMatrix4f_mulTranslate();
            testMatrix4f_mulScale();
            testMatrix4f_mulQuaternion();
            testMatrix3f_mulQuaternion();
            testVector4f_transform();
            testVector3f_transform();
        }

        dbg("Done");
    }

    private static void testMatrix4f_mulTranslate()
    {
        Matrix4f matrix4f = new Matrix4f();
        matrix4f.setRandom(random);
        Matrix4f matrix4f1 = matrix4f.copy();
        float f = random.nextFloat();
        float f1 = random.nextFloat();
        float f2 = random.nextFloat();
        matrix4f.mul(Matrix4f.makeTranslate(f, f1, f2));
        matrix4f1.mulTranslate(f, f1, f2);

        if (!matrix4f1.equals(matrix4f))
        {
            dbg("*** DIFFERENT ***");
            dbg(matrix4f.toString());
            dbg(matrix4f1.toString());
        }
    }

    private static void testMatrix4f_mulScale()
    {
        Matrix4f matrix4f = new Matrix4f();
        matrix4f.setRandom(random);
        Matrix4f matrix4f1 = matrix4f.copy();
        float f = random.nextFloat();
        float f1 = random.nextFloat();
        float f2 = random.nextFloat();
        matrix4f.mul(Matrix4f.makeScale(f, f1, f2));
        matrix4f1.mulScale(f, f1, f2);

        if (!matrix4f1.equals(matrix4f))
        {
            dbg("*** DIFFERENT ***");
            dbg(matrix4f.toString());
            dbg(matrix4f1.toString());
        }
    }

    private static void testMatrix4f_mulQuaternion()
    {
        Matrix4f matrix4f = new Matrix4f();
        matrix4f.setRandom(random);
        Matrix4f matrix4f1 = matrix4f.copy();
        Quaternion quaternion = new Quaternion(random.nextFloat(), random.nextFloat(), random.nextFloat(), random.nextFloat());
        matrix4f.mul(new Matrix4f(quaternion));
        matrix4f1.mul(quaternion);

        if (!matrix4f1.equals(matrix4f))
        {
            dbg("*** DIFFERENT ***");
            dbg(matrix4f.toString());
            dbg(matrix4f1.toString());
        }
    }

    private static void testMatrix3f_mulQuaternion()
    {
        Matrix3f matrix3f = new Matrix3f();
        matrix3f.setRandom(random);
        Matrix3f matrix3f1 = matrix3f.copy();
        Quaternion quaternion = new Quaternion(random.nextFloat(), random.nextFloat(), random.nextFloat(), random.nextFloat());
        matrix3f.mul(new Matrix3f(quaternion));
        matrix3f1.mul(quaternion);

        if (!matrix3f1.equals(matrix3f))
        {
            dbg("*** DIFFERENT ***");
            dbg(matrix3f.toString());
            dbg(matrix3f1.toString());
        }
    }

    private static void testVector3f_transform()
    {
        Vec3f vec3f = new Vec3f(random.nextFloat(), random.nextFloat(), random.nextFloat());
        Vec3f vec3f1 = vec3f.copy();
        Matrix3f matrix3f = new Matrix3f();
        matrix3f.setRandom(random);
        vec3f.transform(matrix3f);
        float f = matrix3f.getTransformX(vec3f1.getX(), vec3f1.getY(), vec3f1.getZ());
        float f1 = matrix3f.getTransformY(vec3f1.getX(), vec3f1.getY(), vec3f1.getZ());
        float f2 = matrix3f.getTransformZ(vec3f1.getX(), vec3f1.getY(), vec3f1.getZ());
        vec3f1 = new Vec3f(f, f1, f2);

        if (!vec3f1.equals(vec3f))
        {
            dbg("*** DIFFERENT ***");
            dbg(vec3f.toString());
            dbg(vec3f1.toString());
        }
    }

    private static void testVector4f_transform()
    {
        Vec4f vec4f = new Vec4f(random.nextFloat(), random.nextFloat(), random.nextFloat(), random.nextFloat());
        Vec4f vec4f1 = new Vec4f(vec4f.getX(), vec4f.getY(), vec4f.getZ(), vec4f.getW());
        Matrix4f matrix4f = new Matrix4f();
        matrix4f.setRandom(random);
        vec4f.transform(matrix4f);
        float f = matrix4f.getTransformX(vec4f1.getX(), vec4f1.getY(), vec4f1.getZ(), vec4f1.getW());
        float f1 = matrix4f.getTransformY(vec4f1.getX(), vec4f1.getY(), vec4f1.getZ(), vec4f1.getW());
        float f2 = matrix4f.getTransformZ(vec4f1.getX(), vec4f1.getY(), vec4f1.getZ(), vec4f1.getW());
        float f3 = matrix4f.getTransformW(vec4f1.getX(), vec4f1.getY(), vec4f1.getZ(), vec4f1.getW());
        vec4f1 = new Vec4f(f, f1, f2, f3);

        if (!vec4f1.equals(vec4f))
        {
            dbg("*** DIFFERENT ***");
            dbg(vec4f.toString());
            dbg(vec4f1.toString());
        }
    }

    private static void dbg(String str)
    {
        System.out.println(str);
    }
}
