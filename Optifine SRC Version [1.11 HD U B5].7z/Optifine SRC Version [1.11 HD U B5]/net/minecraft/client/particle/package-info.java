@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.client.particle;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;