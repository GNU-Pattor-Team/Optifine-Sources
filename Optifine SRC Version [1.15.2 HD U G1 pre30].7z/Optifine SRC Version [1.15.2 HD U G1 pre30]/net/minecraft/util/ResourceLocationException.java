package net.minecraft.util;

public class ResourceLocationException extends RuntimeException
{
    public ResourceLocationException(String p_i3049_1_)
    {
        super(p_i3049_1_);
    }

    public ResourceLocationException(String p_i3050_1_, Throwable p_i3050_2_)
    {
        super(p_i3050_1_, p_i3050_2_);
    }
}
