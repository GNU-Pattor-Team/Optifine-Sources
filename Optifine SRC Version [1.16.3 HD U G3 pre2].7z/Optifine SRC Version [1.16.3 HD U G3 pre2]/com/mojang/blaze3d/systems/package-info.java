@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.mojang.blaze3d.systems;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;