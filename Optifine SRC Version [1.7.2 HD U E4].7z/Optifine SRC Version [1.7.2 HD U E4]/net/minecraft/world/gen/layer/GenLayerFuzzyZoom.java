package net.minecraft.world.gen.layer;

public class GenLayerFuzzyZoom extends GenLayerZoom
{
    private static final String __OBFID = "CL_00000556";

    public GenLayerFuzzyZoom(long par1, GenLayer par3GenLayer)
    {
        super(par1, par3GenLayer);
    }

    protected int func_151617_b(int p_151617_1_, int p_151617_2_, int p_151617_3_, int p_151617_4_)
    {
        return this.func_151619_a(new int[] {p_151617_1_, p_151617_2_, p_151617_3_, p_151617_4_});
    }
}
