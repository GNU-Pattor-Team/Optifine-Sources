package net.minecraft.item;

public class ItemSimpleFoiled extends Item
{
    private static final String __OBFID = "CL_00000065";

    public boolean hasEffect(ItemStack p_77636_1_)
    {
        return true;
    }
}
