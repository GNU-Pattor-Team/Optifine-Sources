package net.minecraft.util;

public class ResourceLocationException extends RuntimeException
{
    public ResourceLocationException(String p_i48222_1_)
    {
        super(p_i48222_1_);
    }

    public ResourceLocationException(String p_i49530_1_, Throwable p_i49530_2_)
    {
        super(p_i49530_1_, p_i49530_2_);
    }
}
