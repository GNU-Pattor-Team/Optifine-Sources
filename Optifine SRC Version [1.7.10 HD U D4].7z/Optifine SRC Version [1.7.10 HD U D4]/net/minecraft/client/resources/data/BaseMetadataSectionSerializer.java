package net.minecraft.client.resources.data;

public abstract class BaseMetadataSectionSerializer implements IMetadataSectionSerializer
{
    private static final String __OBFID = "CL_00001098";
}
