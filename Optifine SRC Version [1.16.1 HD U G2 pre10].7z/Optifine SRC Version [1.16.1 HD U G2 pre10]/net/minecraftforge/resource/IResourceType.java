package net.minecraftforge.resource;

public interface IResourceType
{
}
