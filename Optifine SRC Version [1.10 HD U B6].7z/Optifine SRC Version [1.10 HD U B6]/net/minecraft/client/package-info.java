@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.client;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;