@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.network.login;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;