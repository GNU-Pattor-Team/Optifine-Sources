package net.minecraft.src;

public class TextureAnimationFrame
{
    public int index = 0;
    public int duration = 0;
    public int counter = 0;

    public TextureAnimationFrame(int p_i75_1_, int p_i75_2_)
    {
        this.index = p_i75_1_;
        this.duration = p_i75_2_;
    }
}
