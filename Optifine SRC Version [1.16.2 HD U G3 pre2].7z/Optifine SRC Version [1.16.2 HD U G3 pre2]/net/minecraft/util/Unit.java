package net.minecraft.util;

public enum Unit
{
    INSTANCE;
}
