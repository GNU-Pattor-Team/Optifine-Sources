package net.minecraft.world.gen;

public class NetherGenSettings extends GenerationSettings
{
    public int getBedrockFloorHeight()
    {
        return 0;
    }

    public int getBedrockRoofHeight()
    {
        return 127;
    }
}
