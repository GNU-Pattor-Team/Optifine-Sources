package net.minecraft.entity;

public interface IEntityOwnable
{
    String func_152113_b();

    Entity getOwner();
}
