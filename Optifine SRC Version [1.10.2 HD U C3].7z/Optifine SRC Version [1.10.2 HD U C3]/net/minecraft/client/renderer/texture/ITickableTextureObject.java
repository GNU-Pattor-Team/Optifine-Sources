package net.minecraft.client.renderer.texture;

public interface ITickableTextureObject extends ITextureObject, ITickable
{
}
