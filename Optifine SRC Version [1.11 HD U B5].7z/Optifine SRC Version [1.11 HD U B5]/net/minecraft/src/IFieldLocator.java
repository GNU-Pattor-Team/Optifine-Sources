package net.minecraft.src;

import java.lang.reflect.Field;

public interface IFieldLocator
{
    Field getField();
}
