@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.state;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;