@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.loot.conditions;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;