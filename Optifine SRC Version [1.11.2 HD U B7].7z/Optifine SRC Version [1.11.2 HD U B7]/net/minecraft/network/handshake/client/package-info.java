@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.network.handshake.client;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;