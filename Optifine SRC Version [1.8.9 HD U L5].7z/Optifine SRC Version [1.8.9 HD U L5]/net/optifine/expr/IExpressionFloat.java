package net.optifine.expr;

public interface IExpressionFloat extends IExpression
{
    float eval();
}
