package optifine;

public class TextureAnimationFrame
{
    public int index = 0;
    public int duration = 0;
    public int counter = 0;

    public TextureAnimationFrame(int index, int duration)
    {
        this.index = index;
        this.duration = duration;
    }
}
