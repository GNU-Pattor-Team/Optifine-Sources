package net.optifine.config;

import net.minecraft.util.ResourceLocation;

public interface IObjectLocator
{
    Object getObject(ResourceLocation var1);
}
