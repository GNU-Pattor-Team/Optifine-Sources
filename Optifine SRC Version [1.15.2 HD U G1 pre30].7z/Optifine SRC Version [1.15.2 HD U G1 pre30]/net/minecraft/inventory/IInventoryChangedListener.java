package net.minecraft.inventory;

public interface IInventoryChangedListener
{
    void onInventoryChanged(IInventory invBasic);
}
