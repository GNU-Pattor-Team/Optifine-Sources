@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.loot;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;