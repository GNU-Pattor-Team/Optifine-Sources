package net.minecraft.entity;

public enum EnumCreatureAttribute
{
    UNDEFINED("UNDEFINED", 0),
    UNDEAD("UNDEAD", 1),
    ARTHROPOD("ARTHROPOD", 2);

    private static final EnumCreatureAttribute[] $VALUES = new EnumCreatureAttribute[]{UNDEFINED, UNDEAD, ARTHROPOD};
    private static final String __OBFID = "CL_00001553";

    private EnumCreatureAttribute(String p_i1597_1_, int p_i1597_2_) {}
}
