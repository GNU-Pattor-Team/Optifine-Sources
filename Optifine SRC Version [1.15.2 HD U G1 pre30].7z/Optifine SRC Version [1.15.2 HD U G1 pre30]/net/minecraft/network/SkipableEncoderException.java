package net.minecraft.network;

import io.netty.handler.codec.EncoderException;

public class SkipableEncoderException extends EncoderException
{
    public SkipableEncoderException(Throwable p_i3604_1_)
    {
        super(p_i3604_1_);
    }
}
