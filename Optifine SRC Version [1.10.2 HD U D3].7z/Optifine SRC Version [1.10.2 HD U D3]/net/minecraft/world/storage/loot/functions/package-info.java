@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.world.storage.loot.functions;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;