@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.data.advancements;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;