package net.minecraftforge.client.model.data;

public class EmptyModelData implements IModelData
{
    public static final EmptyModelData INSTANCE = new EmptyModelData();
}
