package net.minecraft.block.state;

import java.util.List;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public interface IBlockProperties
{
    Material getMaterial();

    boolean isFullBlock();

    int getLightOpacity();

    int getlightValue();

    boolean isTranslucent();

    boolean useNeighborBrightness();

    MapColor getMapColor();

    /**
     * Returns the blockstate with the given rotation. If inapplicable, returns itself.
     */
    IBlockState withRotation(Rotation var1);

    /**
     * Returns the blockstate mirrored in the given way. If inapplicable, returns itself.
     */
    IBlockState withMirror(Mirror var1);

    boolean isFullCube();

    EnumBlockRenderType getRenderType();

    int getPackedLightmapCoords(IBlockAccess var1, BlockPos var2);

    float func_185892_j();

    boolean isBlockNormalCube();

    boolean isNormalCube();

    boolean canProvidePower();

    int getWeakPower(IBlockAccess var1, BlockPos var2, EnumFacing var3);

    boolean hasComparatorInputOverride();

    int getComparatorInputOverride(World var1, BlockPos var2);

    float getBlockHardness(World var1, BlockPos var2);

    float getPlayerRelativeBlockHardness(EntityPlayer var1, World var2, BlockPos var3);

    int getStrongPower(IBlockAccess var1, BlockPos var2, EnumFacing var3);

    EnumPushReaction getMobilityFlag();

    IBlockState getActualState(IBlockAccess var1, BlockPos var2);

    AxisAlignedBB getCollisionBoundingBox(World var1, BlockPos var2);

    boolean shouldSideBeRendered(IBlockAccess var1, BlockPos var2, EnumFacing var3);

    boolean isOpaqueCube();

    AxisAlignedBB getSelectedBoundingBox(World var1, BlockPos var2);

    void func_185908_a(World var1, BlockPos var2, AxisAlignedBB var3, List<AxisAlignedBB> var4, Entity var5);

    AxisAlignedBB func_185900_c(IBlockAccess var1, BlockPos var2);

    RayTraceResult func_185910_a(World var1, BlockPos var2, Vec3d var3, Vec3d var4);

    boolean func_185896_q();
}
