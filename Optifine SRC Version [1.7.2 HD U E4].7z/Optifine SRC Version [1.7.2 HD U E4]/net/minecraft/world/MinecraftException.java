package net.minecraft.world;

public class MinecraftException extends Exception
{
    private static final String __OBFID = "CL_00000145";

    public MinecraftException(String par1Str)
    {
        super(par1Str);
    }
}
