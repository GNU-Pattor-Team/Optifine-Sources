package net.minecraft.world.biome;

import java.util.Random;
import net.minecraft.world.gen.feature.WorldGenAbstractTree;

public class BiomeForestMutated extends BiomeForest
{
    public BiomeForestMutated(Biome.BiomeProperties properties)
    {
        super(BiomeForest.Type.BIRCH, properties);
    }

    public WorldGenAbstractTree genBigTreeChance(Random rand)
    {
        return rand.nextBoolean() ? BiomeForest.field_150629_aC : BiomeForest.field_150630_aD;
    }
}
