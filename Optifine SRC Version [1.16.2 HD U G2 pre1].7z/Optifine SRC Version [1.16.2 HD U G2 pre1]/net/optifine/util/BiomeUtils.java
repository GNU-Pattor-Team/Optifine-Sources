package net.optifine.util;

import java.util.Set;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.registry.WorldGenRegistries;
import net.minecraft.world.IBlockDisplayReader;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.Biomes;
import net.optifine.override.ChunkCacheOF;

public class BiomeUtils
{
    public static Biome PLAINS = getBiomeRegistry().func_243576_d(Biomes.PLAINS);
    public static Biome SWAMP = getBiomeRegistry().func_243576_d(Biomes.SWAMP);
    public static Biome SWAMP_HILLS = getBiomeRegistry().func_243576_d(Biomes.SWAMP_HILLS);

    public static Registry<Biome> getBiomeRegistry()
    {
        return WorldGenRegistries.field_243657_i;
    }

    public static ResourceLocation getLocation(Biome biome)
    {
        return getBiomeRegistry().getKey(biome);
    }

    public static int getId(Biome biome)
    {
        return getBiomeRegistry().getId(biome);
    }

    public static Biome getBiome(ResourceLocation loc)
    {
        return !getBiomeRegistry().containsKey(loc) ? null : getBiomeRegistry().getOrDefault(loc);
    }

    public static Biome getBiomeSafe(ResourceLocation loc)
    {
        return getBiomeRegistry().getOrDefault(loc);
    }

    public static Set<ResourceLocation> getLocations()
    {
        return getBiomeRegistry().keySet();
    }

    public static Biome getBiome(IBlockDisplayReader lightReader, BlockPos blockPos)
    {
        Biome biome = PLAINS;

        if (lightReader instanceof ChunkCacheOF)
        {
            biome = ((ChunkCacheOF)lightReader).getBiome(blockPos);
        }
        else if (lightReader instanceof IWorldReader)
        {
            biome = ((IWorldReader)lightReader).getBiome(blockPos);
        }

        return biome;
    }
}
