package net.minecraft.world.gen;

public abstract class NoiseGenerator
{
    private static final String __OBFID = "CL_00000538";
}
