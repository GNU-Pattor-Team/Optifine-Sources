@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.resources.data;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;