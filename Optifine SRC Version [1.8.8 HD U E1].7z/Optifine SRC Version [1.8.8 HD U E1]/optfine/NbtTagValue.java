package optfine;

public class NbtTagValue
{
    private String tag = null;
    private String value = null;

    public NbtTagValue(String p_i45_1_, String p_i45_2_)
    {
        this.tag = p_i45_1_;
        this.value = p_i45_2_;
    }

    public boolean matches(String p_matches_1_, String p_matches_2_)
    {
        return false;
    }
}
