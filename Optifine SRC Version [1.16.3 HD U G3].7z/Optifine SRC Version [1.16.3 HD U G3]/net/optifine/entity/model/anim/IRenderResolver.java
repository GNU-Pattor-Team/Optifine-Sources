package net.optifine.entity.model.anim;

import net.optifine.expr.IExpression;

public interface IRenderResolver
{
    IExpression getParameter(String var1);
}
