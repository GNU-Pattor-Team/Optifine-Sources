package net.minecraft.world.biome.provider;

import net.minecraft.world.storage.WorldInfo;

public class EndBiomeProviderSettings implements IBiomeProviderSettings
{
    private final long seed;

    public EndBiomeProviderSettings(WorldInfo p_i1248_1_)
    {
        this.seed = p_i1248_1_.getSeed();
    }

    public long getSeed()
    {
        return this.seed;
    }
}
