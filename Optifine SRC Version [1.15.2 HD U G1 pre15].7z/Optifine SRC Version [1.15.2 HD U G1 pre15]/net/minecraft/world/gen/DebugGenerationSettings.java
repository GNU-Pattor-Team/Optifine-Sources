package net.minecraft.world.gen;

public class DebugGenerationSettings extends GenerationSettings
{
}
