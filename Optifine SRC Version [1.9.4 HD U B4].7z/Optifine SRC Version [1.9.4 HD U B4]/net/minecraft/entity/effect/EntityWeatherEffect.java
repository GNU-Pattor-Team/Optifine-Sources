package net.minecraft.entity.effect;

import net.minecraft.entity.Entity;
import net.minecraft.world.World;

public abstract class EntityWeatherEffect extends Entity
{
    public EntityWeatherEffect(World worldIn)
    {
        super(worldIn);
    }
}
