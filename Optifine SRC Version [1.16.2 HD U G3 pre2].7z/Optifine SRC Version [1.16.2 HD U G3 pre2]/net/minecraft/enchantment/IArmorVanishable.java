package net.minecraft.enchantment;

public interface IArmorVanishable extends IVanishable
{
}
