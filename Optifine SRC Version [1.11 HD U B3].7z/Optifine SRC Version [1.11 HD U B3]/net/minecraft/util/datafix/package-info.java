@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.util.datafix;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;