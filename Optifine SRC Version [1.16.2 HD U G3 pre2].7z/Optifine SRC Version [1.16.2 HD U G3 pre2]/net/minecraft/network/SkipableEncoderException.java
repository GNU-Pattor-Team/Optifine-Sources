package net.minecraft.network;

import io.netty.handler.codec.EncoderException;

public class SkipableEncoderException extends EncoderException
{
    public SkipableEncoderException(Throwable p_i49718_1_)
    {
        super(p_i49718_1_);
    }
}
