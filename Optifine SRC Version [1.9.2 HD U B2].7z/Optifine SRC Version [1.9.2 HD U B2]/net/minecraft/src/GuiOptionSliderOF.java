package net.minecraft.src;

import net.minecraft.client.gui.GuiOptionSlider;
import net.minecraft.client.settings.GameSettings;

public class GuiOptionSliderOF extends GuiOptionSlider implements IOptionControl
{
    private GameSettings.Options option = null;

    public GuiOptionSliderOF(int p_i27_1_, int p_i27_2_, int p_i27_3_, GameSettings.Options p_i27_4_)
    {
        super(p_i27_1_, p_i27_2_, p_i27_3_, p_i27_4_);
        this.option = p_i27_4_;
    }

    public GameSettings.Options getOption()
    {
        return this.option;
    }
}
