@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.data.loot;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;