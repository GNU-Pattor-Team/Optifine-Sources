package net.minecraft.util;

import net.minecraft.item.Item;

public interface IItemProvider
{
    Item asItem();
}
