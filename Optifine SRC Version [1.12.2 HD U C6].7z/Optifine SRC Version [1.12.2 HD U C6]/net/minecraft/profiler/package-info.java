@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.profiler;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;