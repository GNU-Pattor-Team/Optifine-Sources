@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.world.demo;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;