package net.minecraft.world.chunk;

import net.minecraft.block.state.IBlockState;

interface IBlockStatePaletteResizer
{
    int func_186008_a(int p_186008_1_, IBlockState p_186008_2_);
}
