package net.minecraftforge.eventbus.api;

public class Event
{
}
