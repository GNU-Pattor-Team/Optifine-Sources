package com.mojang.blaze3d.vertex;

import net.minecraft.util.Direction;
import net.minecraft.util.math.vector.Matrix3f;
import net.minecraft.util.math.vector.Matrix4f;
import net.minecraft.util.math.vector.Vec3f;
import net.minecraft.util.math.vector.Vec4f;

public class MatrixApplyingVertexBuilder extends DefaultColorVertexBuilder
{
    private final IVertexBuilder field_227808_g_;
    private final Matrix4f field_227809_h_;
    private final Matrix3f field_227810_i_;
    private float field_227811_j_;
    private float field_227812_k_;
    private float field_227813_l_;
    private int field_227814_m_;
    private int field_227815_n_;
    private int field_227816_o_;
    private float field_227817_p_;
    private float field_227818_q_;
    private float field_227819_r_;

    public MatrixApplyingVertexBuilder(IVertexBuilder p_i2895_1_, Matrix4f p_i2895_2_, Matrix3f p_i2895_3_)
    {
        this.field_227808_g_ = p_i2895_1_;
        this.field_227809_h_ = p_i2895_2_.copy();
        this.field_227809_h_.invert();
        this.field_227810_i_ = p_i2895_3_.copy();
        this.field_227810_i_.invert();
        this.reset();
    }

    private void reset()
    {
        this.field_227811_j_ = 0.0F;
        this.field_227812_k_ = 0.0F;
        this.field_227813_l_ = 0.0F;
        this.field_227814_m_ = 0;
        this.field_227815_n_ = 10;
        this.field_227816_o_ = 15728880;
        this.field_227817_p_ = 0.0F;
        this.field_227818_q_ = 1.0F;
        this.field_227819_r_ = 0.0F;
    }

    public void endVertex()
    {
        Vec3f vec3f = new Vec3f(this.field_227817_p_, this.field_227818_q_, this.field_227819_r_);
        vec3f.transform(this.field_227810_i_);
        Direction direction = Direction.getFacingFromVector(vec3f.getX(), vec3f.getY(), vec3f.getZ());
        Vec4f vec4f = new Vec4f(this.field_227811_j_, this.field_227812_k_, this.field_227813_l_, 1.0F);
        vec4f.transform(this.field_227809_h_);
        vec4f.transform(Vec3f.YP.rotationDegrees(180.0F));
        vec4f.transform(Vec3f.XP.rotationDegrees(-90.0F));
        vec4f.transform(direction.getRotation());
        float f = -vec4f.getX();
        float f1 = -vec4f.getY();
        this.field_227808_g_.pos((double)this.field_227811_j_, (double)this.field_227812_k_, (double)this.field_227813_l_).color(1.0F, 1.0F, 1.0F, 1.0F).tex(f, f1).overlay(this.field_227814_m_, this.field_227815_n_).lightmap(this.field_227816_o_).normal(this.field_227817_p_, this.field_227818_q_, this.field_227819_r_).endVertex();
        this.reset();
    }

    public IVertexBuilder pos(double x, double y, double z)
    {
        this.field_227811_j_ = (float)x;
        this.field_227812_k_ = (float)y;
        this.field_227813_l_ = (float)z;
        return this;
    }

    public IVertexBuilder color(int red, int green, int blue, int alpha)
    {
        return this;
    }

    public IVertexBuilder tex(float u, float v)
    {
        return this;
    }

    public IVertexBuilder overlay(int u, int v)
    {
        this.field_227814_m_ = u;
        this.field_227815_n_ = v;
        return this;
    }

    public IVertexBuilder lightmap(int u, int v)
    {
        this.field_227816_o_ = u | v << 16;
        return this;
    }

    public IVertexBuilder normal(float x, float y, float z)
    {
        this.field_227817_p_ = x;
        this.field_227818_q_ = y;
        this.field_227819_r_ = z;
        return this;
    }
}
