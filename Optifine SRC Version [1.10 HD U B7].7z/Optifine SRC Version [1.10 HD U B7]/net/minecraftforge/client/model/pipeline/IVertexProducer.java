package net.minecraftforge.client.model.pipeline;

public interface IVertexProducer
{
    void pipe(IVertexConsumer var1);
}
