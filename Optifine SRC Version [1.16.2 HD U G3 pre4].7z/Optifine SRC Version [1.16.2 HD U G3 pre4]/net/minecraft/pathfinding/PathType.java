package net.minecraft.pathfinding;

public enum PathType
{
    LAND,
    WATER,
    AIR;
}
