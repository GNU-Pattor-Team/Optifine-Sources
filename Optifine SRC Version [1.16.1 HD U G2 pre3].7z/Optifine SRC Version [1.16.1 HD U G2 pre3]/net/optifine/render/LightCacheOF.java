package net.optifine.render;

import net.minecraft.block.BlockState;
import net.minecraft.client.renderer.BlockModelRenderer;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockDisplayReader;

public class LightCacheOF
{
    public static final float getBrightness(BlockState blockStateIn, IBlockDisplayReader worldIn, BlockPos blockPosIn)
    {
        float f = blockStateIn.getAmbientOcclusionLightValue(worldIn, blockPosIn);
        return BlockModelRenderer.fixAoLightValue(f);
    }

    public static final int getPackedLight(BlockState blockStateIn, IBlockDisplayReader worldIn, BlockPos blockPosIn)
    {
        return WorldRenderer.getPackedLightmapCoords(worldIn, blockStateIn, blockPosIn);
    }
}
