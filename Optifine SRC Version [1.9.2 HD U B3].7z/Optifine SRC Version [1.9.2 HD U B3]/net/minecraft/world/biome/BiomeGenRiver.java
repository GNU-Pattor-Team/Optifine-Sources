package net.minecraft.world.biome;

public class BiomeGenRiver extends BiomeGenBase
{
    public BiomeGenRiver(BiomeGenBase.BiomeProperties properties)
    {
        super(properties);
        this.spawnableCreatureList.clear();
    }
}
