package net.minecraft.block.pattern;

import com.google.common.base.MoreObjects;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.LoadingCache;
import java.util.function.Predicate;
import javax.annotation.Nullable;
import net.minecraft.util.CachedBlockInfo;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.math.vector.Vector3i;
import net.minecraft.world.IWorldReader;

public class BlockPattern
{
    private final Predicate<CachedBlockInfo>[][][] blockMatches;
    private final int fingerLength;
    private final int thumbLength;
    private final int palmLength;

    public BlockPattern(Predicate<CachedBlockInfo>[][][] p_i2615_1_)
    {
        this.blockMatches = p_i2615_1_;
        this.fingerLength = p_i2615_1_.length;

        if (this.fingerLength > 0)
        {
            this.thumbLength = p_i2615_1_[0].length;

            if (this.thumbLength > 0)
            {
                this.palmLength = p_i2615_1_[0][0].length;
            }
            else
            {
                this.palmLength = 0;
            }
        }
        else
        {
            this.thumbLength = 0;
            this.palmLength = 0;
        }
    }

    public int getFingerLength()
    {
        return this.fingerLength;
    }

    public int getThumbLength()
    {
        return this.thumbLength;
    }

    public int getPalmLength()
    {
        return this.palmLength;
    }

    @Nullable
    private BlockPattern.PatternHelper checkPatternAt(BlockPos pos, Direction finger, Direction thumb, LoadingCache<BlockPos, CachedBlockInfo> lcache)
    {
        for (int i = 0; i < this.palmLength; ++i)
        {
            for (int j = 0; j < this.thumbLength; ++j)
            {
                for (int k = 0; k < this.fingerLength; ++k)
                {
                    if (!this.blockMatches[k][j][i].test(lcache.getUnchecked(translateOffset(pos, finger, thumb, i, j, k))))
                    {
                        return null;
                    }
                }
            }
        }

        return new BlockPattern.PatternHelper(pos, finger, thumb, lcache, this.palmLength, this.thumbLength, this.fingerLength);
    }

    @Nullable
    public BlockPattern.PatternHelper match(IWorldReader worldIn, BlockPos pos)
    {
        LoadingCache<BlockPos, CachedBlockInfo> loadingcache = createLoadingCache(worldIn, false);
        int i = Math.max(Math.max(this.palmLength, this.thumbLength), this.fingerLength);

        for (BlockPos blockpos : BlockPos.getAllInBoxMutable(pos, pos.add(i - 1, i - 1, i - 1)))
        {
            for (Direction direction : Direction.values())
            {
                for (Direction direction1 : Direction.values())
                {
                    if (direction1 != direction && direction1 != direction.getOpposite())
                    {
                        BlockPattern.PatternHelper blockpattern$patternhelper = this.checkPatternAt(blockpos, direction, direction1, loadingcache);

                        if (blockpattern$patternhelper != null)
                        {
                            return blockpattern$patternhelper;
                        }
                    }
                }
            }
        }

        return null;
    }

    public static LoadingCache<BlockPos, CachedBlockInfo> createLoadingCache(IWorldReader worldIn, boolean forceLoadIn)
    {
        return CacheBuilder.newBuilder().build(new BlockPattern.CacheLoader(worldIn, forceLoadIn));
    }

    protected static BlockPos translateOffset(BlockPos pos, Direction finger, Direction thumb, int palmOffset, int thumbOffset, int fingerOffset)
    {
        if (finger != thumb && finger != thumb.getOpposite())
        {
            Vector3i vector3i = new Vector3i(finger.getXOffset(), finger.getYOffset(), finger.getZOffset());
            Vector3i vector3i1 = new Vector3i(thumb.getXOffset(), thumb.getYOffset(), thumb.getZOffset());
            Vector3i vector3i2 = vector3i.crossProduct(vector3i1);
            return pos.add(vector3i1.getX() * -thumbOffset + vector3i2.getX() * palmOffset + vector3i.getX() * fingerOffset, vector3i1.getY() * -thumbOffset + vector3i2.getY() * palmOffset + vector3i.getY() * fingerOffset, vector3i1.getZ() * -thumbOffset + vector3i2.getZ() * palmOffset + vector3i.getZ() * fingerOffset);
        }
        else
        {
            throw new IllegalArgumentException("Invalid forwards & up combination");
        }
    }

    static class CacheLoader extends com.google.common.cache.CacheLoader<BlockPos, CachedBlockInfo>
    {
        private final IWorldReader world;
        private final boolean forceLoad;

        public CacheLoader(IWorldReader p_i3204_1_, boolean p_i3204_2_)
        {
            this.world = p_i3204_1_;
            this.forceLoad = p_i3204_2_;
        }

        public CachedBlockInfo load(BlockPos p_load_1_) throws Exception
        {
            return new CachedBlockInfo(this.world, p_load_1_, this.forceLoad);
        }
    }

    public static class PatternHelper
    {
        private final BlockPos frontTopLeft;
        private final Direction forwards;
        private final Direction up;
        private final LoadingCache<BlockPos, CachedBlockInfo> lcache;
        private final int width;
        private final int height;
        private final int depth;

        public PatternHelper(BlockPos p_i590_1_, Direction p_i590_2_, Direction p_i590_3_, LoadingCache<BlockPos, CachedBlockInfo> p_i590_4_, int p_i590_5_, int p_i590_6_, int p_i590_7_)
        {
            this.frontTopLeft = p_i590_1_;
            this.forwards = p_i590_2_;
            this.up = p_i590_3_;
            this.lcache = p_i590_4_;
            this.width = p_i590_5_;
            this.height = p_i590_6_;
            this.depth = p_i590_7_;
        }

        public BlockPos getFrontTopLeft()
        {
            return this.frontTopLeft;
        }

        public Direction getForwards()
        {
            return this.forwards;
        }

        public Direction getUp()
        {
            return this.up;
        }

        public int getWidth()
        {
            return this.width;
        }

        public int getHeight()
        {
            return this.height;
        }

        public CachedBlockInfo translateOffset(int palmOffset, int thumbOffset, int fingerOffset)
        {
            return this.lcache.getUnchecked(BlockPattern.translateOffset(this.frontTopLeft, this.getForwards(), this.getUp(), palmOffset, thumbOffset, fingerOffset));
        }

        public String toString()
        {
            return MoreObjects.toStringHelper(this).add("up", this.up).add("forwards", this.forwards).add("frontTopLeft", this.frontTopLeft).toString();
        }

        public BlockPattern.PortalInfo getPortalInfo(Direction p_222504_1_, BlockPos p_222504_2_, double p_222504_3_, Vector3d p_222504_5_, double p_222504_6_)
        {
            Direction direction = this.getForwards();
            Direction direction1 = direction.rotateY();
            double d1 = (double)(this.getFrontTopLeft().getY() + 1) - p_222504_3_ * (double)this.getHeight();
            double d0;
            double d2;

            if (direction1 == Direction.NORTH)
            {
                d0 = (double)p_222504_2_.getX() + 0.5D;
                d2 = (double)(this.getFrontTopLeft().getZ() + 1) - (1.0D - p_222504_6_) * (double)this.getWidth();
            }
            else if (direction1 == Direction.SOUTH)
            {
                d0 = (double)p_222504_2_.getX() + 0.5D;
                d2 = (double)this.getFrontTopLeft().getZ() + (1.0D - p_222504_6_) * (double)this.getWidth();
            }
            else if (direction1 == Direction.WEST)
            {
                d0 = (double)(this.getFrontTopLeft().getX() + 1) - (1.0D - p_222504_6_) * (double)this.getWidth();
                d2 = (double)p_222504_2_.getZ() + 0.5D;
            }
            else
            {
                d0 = (double)this.getFrontTopLeft().getX() + (1.0D - p_222504_6_) * (double)this.getWidth();
                d2 = (double)p_222504_2_.getZ() + 0.5D;
            }

            double d3;
            double d4;

            if (direction.getOpposite() == p_222504_1_)
            {
                d3 = p_222504_5_.x;
                d4 = p_222504_5_.z;
            }
            else if (direction.getOpposite() == p_222504_1_.getOpposite())
            {
                d3 = -p_222504_5_.x;
                d4 = -p_222504_5_.z;
            }
            else if (direction.getOpposite() == p_222504_1_.rotateY())
            {
                d3 = -p_222504_5_.z;
                d4 = p_222504_5_.x;
            }
            else
            {
                d3 = p_222504_5_.z;
                d4 = -p_222504_5_.x;
            }

            int i = (direction.getHorizontalIndex() - p_222504_1_.getOpposite().getHorizontalIndex()) * 90;
            return new BlockPattern.PortalInfo(new Vector3d(d0, d1, d2), new Vector3d(d3, p_222504_5_.y, d4), i);
        }
    }

    public static class PortalInfo
    {
        public final Vector3d pos;
        public final Vector3d motion;
        public final int rotation;

        public PortalInfo(Vector3d p_i1714_1_, Vector3d p_i1714_2_, int p_i1714_3_)
        {
            this.pos = p_i1714_1_;
            this.motion = p_i1714_2_;
            this.rotation = p_i1714_3_;
        }
    }
}
