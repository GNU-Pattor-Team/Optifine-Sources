package net.minecraft.item;

import net.minecraft.block.Block;

public class ItemShulkerBox extends ItemBlock
{
    public ItemShulkerBox(Block p_i47260_1_)
    {
        super(p_i47260_1_);
        this.setMaxStackSize(1);
    }
}
