package net.minecraft.client.renderer.texture;

public interface ITextureMapPopulator
{
    void registerSprites(TextureMap textureMapIn);
}
