package net.minecraftforge.client.model.data;

public interface IModelData
{
}
