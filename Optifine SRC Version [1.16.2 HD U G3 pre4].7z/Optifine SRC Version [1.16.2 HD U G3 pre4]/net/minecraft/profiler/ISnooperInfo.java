package net.minecraft.profiler;

public interface ISnooperInfo
{
    void fillSnooper(Snooper snooper);
}
