package net.minecraft.src;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import net.minecraft.util.ResourceLocation;

public class FontUtils
{
    public static void readCustomCharWidths(ResourceLocation p_readCustomCharWidths_0_, float[] p_readCustomCharWidths_1_)
    {
        String s = p_readCustomCharWidths_0_.getResourcePath();
        String s1 = ".png";

        if (s.endsWith(s1))
        {
            String s2 = s.substring(0, s.length() - s1.length()) + ".properties";

            try
            {
                ResourceLocation resourcelocation = new ResourceLocation(p_readCustomCharWidths_0_.getResourceDomain(), s2);
                InputStream inputstream = Config.getResourceStream(Config.getResourceManager(), resourcelocation);

                if (inputstream == null)
                {
                    return;
                }

                Config.log("Loading " + s2);
                Properties properties = new Properties();
                properties.load(inputstream);

                for (Object s30 : properties.keySet())
                {
                    String s3 = (String) s30;
                    String s4 = "width.";

                    if (s3.startsWith(s4))
                    {
                        String s5 = s3.substring(s4.length());
                        int i = Config.parseInt(s5, -1);

                        if (i >= 0 && i < p_readCustomCharWidths_1_.length)
                        {
                            String s6 = properties.getProperty(s3);
                            float f = Config.parseFloat(s6, -1.0F);

                            if (f >= 0.0F)
                            {
                                p_readCustomCharWidths_1_[i] = f;
                            }
                        }
                    }
                }
            }
            catch (FileNotFoundException var16)
            {
                ;
            }
            catch (IOException ioexception)
            {
                ioexception.printStackTrace();
            }
        }
    }

    public static ResourceLocation getHdFontLocation(ResourceLocation p_getHdFontLocation_0_)
    {
        if (!Config.isCustomFonts())
        {
            return p_getHdFontLocation_0_;
        }
        else if (p_getHdFontLocation_0_ == null)
        {
            return p_getHdFontLocation_0_;
        }
        else
        {
            String s = p_getHdFontLocation_0_.getResourcePath();
            String s1 = "textures/";
            String s2 = "mcpatcher/";

            if (!s.startsWith(s1))
            {
                return p_getHdFontLocation_0_;
            }
            else
            {
                s = s.substring(s1.length());
                s = s2 + s;
                ResourceLocation resourcelocation = new ResourceLocation(p_getHdFontLocation_0_.getResourceDomain(), s);
                return Config.hasResource(Config.getResourceManager(), resourcelocation) ? resourcelocation : p_getHdFontLocation_0_;
            }
        }
    }
}
