@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.state.properties;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;