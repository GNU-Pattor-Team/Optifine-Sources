package net.optifine.gui;

import net.minecraft.client.settings.GameSettings;

public interface IOptionControl
{
    GameSettings.Options getOption();
}
