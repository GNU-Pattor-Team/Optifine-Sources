package net.minecraft.item;

public enum UseAction
{
    NONE,
    EAT,
    DRINK,
    BLOCK,
    BOW,
    SPEAR,
    CROSSBOW;
}
