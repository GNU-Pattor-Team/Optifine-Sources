package net.minecraft.item;

public enum EnumAction
{
    none,
    eat,
    drink,
    block,
    bow;
    private static final String __OBFID = "CL_00000073";
}
