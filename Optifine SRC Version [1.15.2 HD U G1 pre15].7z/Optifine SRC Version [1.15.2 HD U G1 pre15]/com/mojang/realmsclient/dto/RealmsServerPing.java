package com.mojang.realmsclient.dto;

public class RealmsServerPing extends ValueObject
{
    public volatile String nrOfPlayers = "0";
    public volatile String playerList = "";
}
