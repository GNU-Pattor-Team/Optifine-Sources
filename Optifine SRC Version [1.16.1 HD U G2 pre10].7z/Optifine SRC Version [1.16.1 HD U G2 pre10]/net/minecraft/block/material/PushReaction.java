package net.minecraft.block.material;

public enum PushReaction
{
    NORMAL,
    DESTROY,
    BLOCK,
    IGNORE,
    PUSH_ONLY;
}
