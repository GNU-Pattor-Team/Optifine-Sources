package com.mojang.realmsclient.client;

public class UploadStatus
{
    public volatile Long field_224978_a = 0L;
    public volatile Long field_224979_b = 0L;
}
