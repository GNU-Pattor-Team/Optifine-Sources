package net.minecraft.profiler;

public interface IResultableProfiler extends IProfiler
{
    IProfileResult getResults();
}
