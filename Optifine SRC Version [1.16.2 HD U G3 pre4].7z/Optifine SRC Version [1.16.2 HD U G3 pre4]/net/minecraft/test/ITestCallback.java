package net.minecraft.test;

public interface ITestCallback
{
    void func_225644_a_(TestTracker p_225644_1_);

    void func_225645_c_(TestTracker p_225645_1_);
}
