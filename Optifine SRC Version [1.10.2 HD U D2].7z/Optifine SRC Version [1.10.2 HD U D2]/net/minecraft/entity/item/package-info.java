@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.entity.item;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;