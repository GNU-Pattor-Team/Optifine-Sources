package net.minecraft.src;

public class TextureAnimationFrame
{
    public int index = 0;
    public int duration = 0;
    public int counter = 0;

    public TextureAnimationFrame(int p_i67_1_, int p_i67_2_)
    {
        this.index = p_i67_1_;
        this.duration = p_i67_2_;
    }
}
