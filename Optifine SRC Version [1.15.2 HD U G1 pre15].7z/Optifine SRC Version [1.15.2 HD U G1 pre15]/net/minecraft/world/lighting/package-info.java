@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.world.lighting;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;