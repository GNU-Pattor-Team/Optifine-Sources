package net.minecraft.util;

public interface ITickable
{
    /**
     * Like the old updateEntity(), except more generic.
     */
    void update();
}
