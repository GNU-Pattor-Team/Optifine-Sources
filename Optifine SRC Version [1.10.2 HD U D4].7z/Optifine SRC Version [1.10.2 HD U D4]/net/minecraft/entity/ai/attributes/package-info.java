@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.entity.ai.attributes;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;