package net.minecraft.stats;

import net.minecraft.scoreboard.ScoreDummyCriteria;

public class ObjectiveStat extends ScoreDummyCriteria
{
    private final StatBase field_151459_g;
    private static final String __OBFID = "CL_00000625";

    public ObjectiveStat(StatBase p_i45483_1_)
    {
        super(p_i45483_1_.statId);
        this.field_151459_g = p_i45483_1_;
    }
}
