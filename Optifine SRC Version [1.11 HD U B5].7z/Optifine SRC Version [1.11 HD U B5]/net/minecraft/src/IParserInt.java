package net.minecraft.src;

public interface IParserInt
{
    int parse(String var1, int var2);
}
