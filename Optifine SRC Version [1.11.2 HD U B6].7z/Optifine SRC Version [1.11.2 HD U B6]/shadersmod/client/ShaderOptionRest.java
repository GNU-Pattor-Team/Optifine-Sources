package shadersmod.client;

public class ShaderOptionRest extends ShaderOption
{
    public ShaderOptionRest(String name)
    {
        super(name, name, (String)null, new String[] {null}, (String)null, (String)null);
    }
}
