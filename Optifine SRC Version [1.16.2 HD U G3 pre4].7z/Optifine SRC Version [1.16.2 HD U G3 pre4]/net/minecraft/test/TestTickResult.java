package net.minecraft.test;

import javax.annotation.Nullable;

class TestTickResult
{
    @Nullable
    public final Long field_229485_a_ = null;
    public final Runnable field_229486_b_ = null;

    private TestTickResult()
    {
        throw new RuntimeException("Synthetic constructor added by MCP, do not call");
    }
}
