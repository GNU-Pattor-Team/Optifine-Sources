package net.minecraft.world.chunk;

public interface IChunkProvider
{
    Chunk getLoadedChunk(int var1, int var2);

    Chunk func_186025_d(int var1, int var2);

    /**
     * Unloads chunks that are marked to be unloaded. This is not guaranteed to unload every such chunk.
     */
    boolean unloadQueuedChunks();

    /**
     * Converts the instance data to a readable string.
     */
    String makeString();
}
