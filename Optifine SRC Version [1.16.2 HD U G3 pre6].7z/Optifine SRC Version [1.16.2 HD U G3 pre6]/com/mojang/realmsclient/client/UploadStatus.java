package com.mojang.realmsclient.client;

public class UploadStatus
{
    public volatile long field_224978_a;
    public volatile long field_224979_b;
}
