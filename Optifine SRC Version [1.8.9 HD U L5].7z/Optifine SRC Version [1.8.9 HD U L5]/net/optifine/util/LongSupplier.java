package net.optifine.util;

public interface LongSupplier
{
    long getAsLong();
}
