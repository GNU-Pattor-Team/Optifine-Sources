@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.client.settings;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;