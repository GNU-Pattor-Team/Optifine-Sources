package net.optifine.expr;

public interface IExpression
{
    ExpressionType getExpressionType();
}
