package net.minecraft.network;

public enum PacketDirection
{
    SERVERBOUND,
    CLIENTBOUND;
}
