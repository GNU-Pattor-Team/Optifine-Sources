package net.minecraft.world.gen;

public interface INoiseGenerator
{
    double noiseAt(double x, double y, double z, double p_215460_7_);
}
