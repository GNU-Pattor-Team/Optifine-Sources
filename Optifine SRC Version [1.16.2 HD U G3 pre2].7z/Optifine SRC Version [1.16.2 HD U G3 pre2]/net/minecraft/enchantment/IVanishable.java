package net.minecraft.enchantment;

public interface IVanishable
{
}
