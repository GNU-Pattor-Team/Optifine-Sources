package net.optifine.config;

public interface INameGetter<T>
{
    String getName(T var1);
}
