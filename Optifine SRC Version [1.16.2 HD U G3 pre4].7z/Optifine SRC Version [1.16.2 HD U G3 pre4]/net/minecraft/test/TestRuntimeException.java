package net.minecraft.test;

public class TestRuntimeException extends RuntimeException
{
    public TestRuntimeException(String p_i226064_1_)
    {
        super(p_i226064_1_);
    }
}
