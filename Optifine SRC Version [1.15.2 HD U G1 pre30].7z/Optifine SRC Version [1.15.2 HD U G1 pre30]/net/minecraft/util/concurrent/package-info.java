@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.util.concurrent;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;