package net.optifine.gui;

public class GuiScreenButtonOF extends GuiButtonOF
{
    public GuiScreenButtonOF(int buttonId, int x, int y, String buttonText)
    {
        super(buttonId, x, y, 150, 20, buttonText);
    }
}
