package net.minecraft.nbt;

public class NBTException extends Exception
{
    public NBTException(String message)
    {
        super(message);
    }
}
