@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.inventory.container;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;