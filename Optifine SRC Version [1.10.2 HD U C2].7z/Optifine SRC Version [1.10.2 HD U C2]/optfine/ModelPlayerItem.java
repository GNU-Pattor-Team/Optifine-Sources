package optfine;

import net.minecraft.client.model.ModelBase;

public class ModelPlayerItem extends ModelBase
{
    public ModelPlayerItem()
    {
        this.isChild = false;
    }
}
