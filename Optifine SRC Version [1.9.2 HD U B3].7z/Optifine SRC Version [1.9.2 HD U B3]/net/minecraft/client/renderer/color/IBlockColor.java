package net.minecraft.client.renderer.color;

import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;

public interface IBlockColor
{
    int func_186720_a(IBlockState p_186720_1_, IBlockAccess p_186720_2_, BlockPos p_186720_3_, int p_186720_4_);
}
