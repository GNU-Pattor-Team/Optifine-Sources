@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.mojang.blaze3d.platform;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;