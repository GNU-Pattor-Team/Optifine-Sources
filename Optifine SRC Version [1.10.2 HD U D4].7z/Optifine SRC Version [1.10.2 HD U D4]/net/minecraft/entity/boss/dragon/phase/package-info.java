@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.entity.boss.dragon.phase;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;