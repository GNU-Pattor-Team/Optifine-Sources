@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.enchantment;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;