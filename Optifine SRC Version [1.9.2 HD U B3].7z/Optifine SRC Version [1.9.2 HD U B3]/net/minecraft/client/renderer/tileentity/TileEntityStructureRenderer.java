package net.minecraft.client.renderer.tileentity;

import net.minecraft.tileentity.TileEntityStructure;

public class TileEntityStructureRenderer extends TileEntitySpecialRenderer<TileEntityStructure>
{
    public void renderTileEntityAt(TileEntityStructure te, double x, double y, double z, float partialTicks, int destroyStage)
    {
    }

    public boolean func_188185_a(TileEntityStructure p_188185_1_)
    {
        return true;
    }
}
