package shadersmod.common;

public class SMCVersion
{
    public static final String mcVersion = "1.11.2";
    public static final String versionString = "2.4.12";
    public static final int versionNumber = 132108;
    public static final int buildNumber = 83;
}
