package com.mojang.realmsclient.gui.screens;

import com.google.common.collect.Lists;
import com.mojang.blaze3d.matrix.MatrixStack;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import net.minecraft.client.gui.DialogTexts;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.client.gui.widget.list.ExtendedList;
import net.minecraft.client.resources.I18n;
import net.minecraft.realms.RealmsLabel;
import net.minecraft.realms.RealmsNarratorHelper;
import net.minecraft.realms.RealmsObjectSelectionList;
import net.minecraft.realms.RealmsScreen;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.storage.WorldSummary;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class RealmsSelectFileToUploadScreen extends RealmsScreen
{
    private static final Logger field_224547_a = LogManager.getLogger();
    private static final DateFormat field_224552_f = new SimpleDateFormat();
    private final RealmsResetWorldScreen field_224548_b;
    private final long field_224549_c;
    private final int field_224550_d;
    private Button field_224551_e;
    private List<WorldSummary> field_224553_g = Lists.newArrayList();
    private int field_224554_h = -1;
    private RealmsSelectFileToUploadScreen.WorldSelectionList field_224555_i;
    private String field_224556_j;
    private String field_224557_k;
    private RealmsLabel field_224559_m;
    private RealmsLabel field_224560_n;
    private RealmsLabel field_224561_o;
    private final Runnable field_237967_A_;

    public RealmsSelectFileToUploadScreen(long p_i646_1_, int p_i646_3_, RealmsResetWorldScreen p_i646_4_, Runnable p_i646_5_)
    {
        this.field_224548_b = p_i646_4_;
        this.field_224549_c = p_i646_1_;
        this.field_224550_d = p_i646_3_;
        this.field_237967_A_ = p_i646_5_;
    }

    private void func_224541_a() throws Exception
    {
        this.field_224553_g = this.minecraft.getSaveLoader().getSaveList().stream().sorted((p_237970_0_, p_237970_1_) ->
        {
            if (p_237970_0_.getLastTimePlayed() < p_237970_1_.getLastTimePlayed())
            {
                return 1;
            }
            else {
                return p_237970_0_.getLastTimePlayed() > p_237970_1_.getLastTimePlayed() ? -1 : p_237970_0_.getFileName().compareTo(p_237970_1_.getFileName());
            }
        }).collect(Collectors.toList());

        for (WorldSummary worldsummary : this.field_224553_g)
        {
            this.field_224555_i.func_237986_a_(worldsummary);
        }
    }

    public void init()
    {
        this.minecraft.keyboardListener.enableRepeatEvents(true);
        this.field_224555_i = new RealmsSelectFileToUploadScreen.WorldSelectionList();

        try
        {
            this.func_224541_a();
        }
        catch (Exception exception)
        {
            field_224547_a.error("Couldn't load level list", (Throwable)exception);
            this.minecraft.displayGuiScreen(new RealmsGenericErrorScreen(new StringTextComponent("Unable to load worlds"), ITextComponent.func_241827_a_(exception.getMessage()), this.field_224548_b));
            return;
        }

        this.field_224556_j = I18n.format("selectWorld.world");
        this.field_224557_k = I18n.format("selectWorld.conversion");
        this.renderTooltip(this.field_224555_i);
        this.field_224551_e = this.addButton(new Button(this.width / 2 - 154, this.height - 32, 153, 20, new TranslationTextComponent("mco.upload.button.name"), (p_237976_1_) ->
        {
            this.func_224544_b();
        }));
        this.field_224551_e.active = this.field_224554_h >= 0 && this.field_224554_h < this.field_224553_g.size();
        this.addButton(new Button(this.width / 2 + 6, this.height - 32, 153, 20, DialogTexts.field_240637_h_, (p_237973_1_) ->
        {
            this.minecraft.displayGuiScreen(this.field_224548_b);
        }));
        this.field_224559_m = this.renderTooltip(new RealmsLabel(new TranslationTextComponent("mco.upload.select.world.title"), this.width / 2, 13, 16777215));
        this.field_224560_n = this.renderTooltip(new RealmsLabel(new TranslationTextComponent("mco.upload.select.world.subtitle"), this.width / 2, func_239562_k_(-1), 10526880));

        if (this.field_224553_g.isEmpty())
        {
            this.field_224561_o = this.renderTooltip(new RealmsLabel(new TranslationTextComponent("mco.upload.select.world.none"), this.width / 2, this.height / 2 - 20, 16777215));
        }
        else
        {
            this.field_224561_o = null;
        }

        this.func_231411_u_();
    }

    public void removed()
    {
        this.minecraft.keyboardListener.enableRepeatEvents(false);
    }

    private void func_224544_b()
    {
        if (this.field_224554_h != -1 && !this.field_224553_g.get(this.field_224554_h).isHardcoreModeEnabled())
        {
            WorldSummary worldsummary = this.field_224553_g.get(this.field_224554_h);
            this.minecraft.displayGuiScreen(new RealmsUploadScreen(this.field_224549_c, this.field_224550_d, this.field_224548_b, worldsummary, this.field_237967_A_));
        }
    }

    public void render(MatrixStack p_230430_1_, int p_230430_2_, int p_230430_3_, float p_230430_4_)
    {
        this.renderBackground(p_230430_1_);
        this.field_224555_i.render(p_230430_1_, p_230430_2_, p_230430_3_, p_230430_4_);
        this.field_224559_m.func_239560_a_(this, p_230430_1_);
        this.field_224560_n.func_239560_a_(this, p_230430_1_);

        if (this.field_224561_o != null)
        {
            this.field_224561_o.func_239560_a_(this, p_230430_1_);
        }

        super.render(p_230430_1_, p_230430_2_, p_230430_3_, p_230430_4_);
    }

    public boolean keyPressed(int p_231046_1_, int p_231046_2_, int p_231046_3_)
    {
        if (p_231046_1_ == 256)
        {
            this.minecraft.displayGuiScreen(this.field_224548_b);
            return true;
        }
        else
        {
            return super.keyPressed(p_231046_1_, p_231046_2_, p_231046_3_);
        }
    }

    private static String func_237977_c_(WorldSummary p_237977_0_)
    {
        return p_237977_0_.getEnumGameType().getDisplayName().getString();
    }

    private static String func_237979_d_(WorldSummary p_237979_0_)
    {
        return field_224552_f.format(new Date(p_237979_0_.getLastTimePlayed()));
    }

    class WorldSelectionEntry extends ExtendedList.AbstractListEntry<RealmsSelectFileToUploadScreen.WorldSelectionEntry>
    {
        private final WorldSummary field_223759_a;

        public WorldSelectionEntry(WorldSummary p_i4373_2_)
        {
            this.field_223759_a = p_i4373_2_;
        }

        public void render(MatrixStack p_230432_1_, int p_230432_2_, int p_230432_3_, int p_230432_4_, int p_230432_5_, int p_230432_6_, int p_230432_7_, int p_230432_8_, boolean p_230432_9_, float p_230432_10_)
        {
            this.func_237985_a_(p_230432_1_, this.field_223759_a, p_230432_2_, p_230432_4_, p_230432_3_);
        }

        public boolean mouseClicked(double p_231044_1_, double p_231044_3_, int p_231044_5_)
        {
            RealmsSelectFileToUploadScreen.this.field_224555_i.func_231400_a_(RealmsSelectFileToUploadScreen.this.field_224553_g.indexOf(this.field_223759_a));
            return true;
        }

        protected void func_237985_a_(MatrixStack p_237985_1_, WorldSummary p_237985_2_, int p_237985_3_, int p_237985_4_, int p_237985_5_)
        {
            String s = p_237985_2_.getDisplayName();

            if (s == null || s.isEmpty())
            {
                s = RealmsSelectFileToUploadScreen.this.field_224556_j + " " + (p_237985_3_ + 1);
            }

            String s1 = p_237985_2_.getFileName();
            s1 = s1 + " (" + RealmsSelectFileToUploadScreen.func_237979_d_(p_237985_2_);
            s1 = s1 + ")";
            String s2 = "";

            if (p_237985_2_.requiresConversion())
            {
                s2 = RealmsSelectFileToUploadScreen.this.field_224557_k + " " + s2;
            }
            else
            {
                s2 = RealmsSelectFileToUploadScreen.func_237977_c_(p_237985_2_);

                if (p_237985_2_.isHardcoreModeEnabled())
                {
                    s2 = TextFormatting.DARK_RED + I18n.format("mco.upload.hardcore") + TextFormatting.RESET;
                }

                if (p_237985_2_.getCheatsEnabled())
                {
                    s2 = s2 + ", " + I18n.format("selectWorld.cheats");
                }
            }

            RealmsSelectFileToUploadScreen.this.font.drawString(p_237985_1_, s, (float)(p_237985_4_ + 2), (float)(p_237985_5_ + 1), 16777215);
            RealmsSelectFileToUploadScreen.this.font.drawString(p_237985_1_, s1, (float)(p_237985_4_ + 2), (float)(p_237985_5_ + 12), 8421504);
            RealmsSelectFileToUploadScreen.this.font.drawString(p_237985_1_, s2, (float)(p_237985_4_ + 2), (float)(p_237985_5_ + 12 + 10), 8421504);
        }
    }

    class WorldSelectionList extends RealmsObjectSelectionList<RealmsSelectFileToUploadScreen.WorldSelectionEntry>
    {
        public WorldSelectionList()
        {
            super(RealmsSelectFileToUploadScreen.this.width, RealmsSelectFileToUploadScreen.this.height, RealmsSelectFileToUploadScreen.func_239562_k_(0), RealmsSelectFileToUploadScreen.this.height - 40, 36);
        }

        public void func_237986_a_(WorldSummary p_237986_1_)
        {
            this.addEntry(RealmsSelectFileToUploadScreen.this.new WorldSelectionEntry(p_237986_1_));
        }

        public int getMaxPosition()
        {
            return RealmsSelectFileToUploadScreen.this.field_224553_g.size() * 36;
        }

        public boolean isFocused()
        {
            return RealmsSelectFileToUploadScreen.this.getFocused() == this;
        }

        public void renderBackground(MatrixStack p_230433_1_)
        {
            RealmsSelectFileToUploadScreen.this.renderBackground(p_230433_1_);
        }

        public void func_231400_a_(int p_231400_1_)
        {
            this.func_239561_k_(p_231400_1_);

            if (p_231400_1_ != -1)
            {
                WorldSummary worldsummary = RealmsSelectFileToUploadScreen.this.field_224553_g.get(p_231400_1_);
                String s = I18n.format("narrator.select.list.position", p_231400_1_ + 1, RealmsSelectFileToUploadScreen.this.field_224553_g.size());
                String s1 = RealmsNarratorHelper.func_239552_b_(Arrays.asList(worldsummary.getDisplayName(), RealmsSelectFileToUploadScreen.func_237979_d_(worldsummary), RealmsSelectFileToUploadScreen.func_237977_c_(worldsummary), s));
                RealmsNarratorHelper.func_239550_a_(I18n.format("narrator.select", s1));
            }
        }

        public void setSelected(@Nullable RealmsSelectFileToUploadScreen.WorldSelectionEntry p_241215_1_)
        {
            super.setSelected(p_241215_1_);
            RealmsSelectFileToUploadScreen.this.field_224554_h = this.children().indexOf(p_241215_1_);
            RealmsSelectFileToUploadScreen.this.field_224551_e.active = RealmsSelectFileToUploadScreen.this.field_224554_h >= 0 && RealmsSelectFileToUploadScreen.this.field_224554_h < this.getItemCount() && !RealmsSelectFileToUploadScreen.this.field_224553_g.get(RealmsSelectFileToUploadScreen.this.field_224554_h).isHardcoreModeEnabled();
        }
    }
}
