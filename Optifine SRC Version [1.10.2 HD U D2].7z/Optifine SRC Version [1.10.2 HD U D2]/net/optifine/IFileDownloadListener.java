package net.optifine;

public interface IFileDownloadListener
{
    void fileDownloadFinished(String var1, byte[] var2, Throwable var3);
}
