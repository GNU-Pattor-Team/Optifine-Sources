package net.minecraft.util.palette;

interface IResizeCallback<T>
{
    int onResize(int p_onResize_1_, T p_onResize_2_);
}
