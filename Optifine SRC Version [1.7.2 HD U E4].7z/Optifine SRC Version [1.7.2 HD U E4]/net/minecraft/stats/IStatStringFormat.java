package net.minecraft.stats;

public interface IStatStringFormat
{
    /**
     * Formats the strings based on 'IStatStringFormat' interface.
     */
    String formatString(String var1);
}
