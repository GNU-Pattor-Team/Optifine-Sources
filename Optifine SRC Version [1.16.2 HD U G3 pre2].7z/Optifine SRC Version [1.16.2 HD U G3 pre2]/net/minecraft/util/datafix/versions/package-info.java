@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.util.datafix.versions;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;