@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.client.resources.data;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;