package net.minecraft.util;

public class MinecraftError extends Error
{
    private static final String __OBFID = "CL_00000657";
}
