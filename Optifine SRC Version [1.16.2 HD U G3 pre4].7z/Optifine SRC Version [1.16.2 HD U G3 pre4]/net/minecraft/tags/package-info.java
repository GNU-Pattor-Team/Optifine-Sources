@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.tags;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;