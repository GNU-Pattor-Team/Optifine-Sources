@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.entity.ai;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;