package net.minecraftforge.common.model;

import net.minecraft.client.renderer.Matrix4f;
import org.apache.commons.lang3.NotImplementedException;

public class TRSRTransformation
{
    public TRSRTransformation(Matrix4f matrix)
    {
        throw new NotImplementedException("Forge dummy class");
    }

    public static boolean isInteger(javax.vecmath.Matrix4f matrix)
    {
        throw new NotImplementedException("Forge dummy class");
    }
}
