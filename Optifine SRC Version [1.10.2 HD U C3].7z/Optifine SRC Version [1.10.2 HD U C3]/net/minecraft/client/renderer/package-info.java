@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.client.renderer;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;