package net.minecraft.profiler;

import it.unimi.dsi.fastutil.objects.Object2LongMap;

public interface IProfilerSection
{
    long func_230037_a_();

    long func_230038_b_();

    Object2LongMap<String> func_230039_c_();
}
