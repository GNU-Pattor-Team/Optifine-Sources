package net.optifine.entity.model;

import net.minecraft.entity.EntityType;

public class ModelAdapterPiglinBrute extends ModelAdapterPiglin
{
    public ModelAdapterPiglinBrute()
    {
        super(EntityType.field_242287_aj, "piglin_brute", 0.5F);
    }
}
