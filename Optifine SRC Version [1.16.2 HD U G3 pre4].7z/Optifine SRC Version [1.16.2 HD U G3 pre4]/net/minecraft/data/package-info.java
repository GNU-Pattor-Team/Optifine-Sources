@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.data;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;