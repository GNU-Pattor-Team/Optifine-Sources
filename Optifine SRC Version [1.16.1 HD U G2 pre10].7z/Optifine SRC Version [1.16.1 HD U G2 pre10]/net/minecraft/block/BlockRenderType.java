package net.minecraft.block;

public enum BlockRenderType
{
    INVISIBLE,
    ENTITYBLOCK_ANIMATED,
    MODEL;
}
