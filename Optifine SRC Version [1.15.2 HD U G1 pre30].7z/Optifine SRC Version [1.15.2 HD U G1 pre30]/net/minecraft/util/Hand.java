package net.minecraft.util;

public enum Hand
{
    MAIN_HAND,
    OFF_HAND;
}
