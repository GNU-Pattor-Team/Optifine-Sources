@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.client.resources;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;