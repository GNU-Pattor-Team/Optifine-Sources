package net.minecraft.util;

public interface IObjectIntIterable<V> extends Iterable<V>
{
}
