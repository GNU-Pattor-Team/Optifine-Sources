package net.minecraft.world.biome;

public class BiomeGenRiver extends BiomeGenBase
{
    private static final String __OBFID = "CL_00000181";

    public BiomeGenRiver(int par1)
    {
        super(par1);
        this.spawnableCreatureList.clear();
    }
}
