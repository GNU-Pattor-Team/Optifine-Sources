package net.minecraft.test;

public interface ITestLogger
{
    void func_225646_a_(TestTracker p_225646_1_);
}
