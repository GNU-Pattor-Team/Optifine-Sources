package com.mojang.realmsclient.gui;

public class RealmsConstants
{
    public static int func_225109_a(int p_225109_0_)
    {
        return 40 + p_225109_0_ * 13;
    }
}
