package net.minecraft.client.resources.data;

public interface IMetadataSection
{
}
