@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.util.palette;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;