@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.network;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;