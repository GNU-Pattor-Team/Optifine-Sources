package net.minecraft.client.renderer.debug;

import net.minecraft.client.Minecraft;

public class DebugRendererWater
{
    private final Minecraft field_188288_a;

    public DebugRendererWater(Minecraft p_i46555_1_)
    {
        this.field_188288_a = p_i46555_1_;
    }
}
