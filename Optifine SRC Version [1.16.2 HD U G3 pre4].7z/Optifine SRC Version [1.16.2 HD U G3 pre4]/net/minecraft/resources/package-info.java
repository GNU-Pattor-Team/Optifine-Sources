@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.resources;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;