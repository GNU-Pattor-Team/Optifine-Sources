package net.minecraft.block;

public class GlassBlock extends AbstractGlassBlock
{
    public GlassBlock(AbstractBlock.Properties p_i3124_1_)
    {
        super(p_i3124_1_);
    }
}
