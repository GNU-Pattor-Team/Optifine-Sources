package net.minecraft.tags;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Lists;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.util.JSONUtils;
import net.minecraft.util.ResourceLocation;

public interface ITag<T>
{
    static <T> Codec<ITag<T>> func_232947_a_(Supplier<TagCollection<T>> p_232947_0_)
    {
        return ResourceLocation.field_240908_a_.flatXmap((p_232949_1_) ->
        {
            return Optional.ofNullable(p_232947_0_.get().get(p_232949_1_)).map(DataResult::success).orElseGet(() -> {
                return DataResult.error("Unknown tag: " + p_232949_1_);
            });
        }, (p_232948_1_) ->
        {
            return Optional.ofNullable(p_232947_0_.get().func_232973_a_(p_232948_1_)).map(DataResult::success).orElseGet(() -> {
                return DataResult.error("Unknown tag: " + p_232948_1_);
            });
        });
    }

    boolean func_230235_a_(T p_230235_1_);

    List<T> func_230236_b_();

default T getRandomElement(Random random)
    {
        List<T> list = this.func_230236_b_();
        return list.get(random.nextInt(list.size()));
    }

    static <T> ITag<T> func_232946_a_(Set<T> p_232946_0_)
    {
        return Tag.func_241286_a_(p_232946_0_);
    }

    public static class Builder
    {
        private final List<ITag.Proxy> field_232953_a_ = Lists.newArrayList();

        public static ITag.Builder create()
        {
            return new ITag.Builder();
        }

        public ITag.Builder func_232954_a_(ITag.Proxy p_232954_1_)
        {
            this.field_232953_a_.add(p_232954_1_);
            return this;
        }

        public ITag.Builder func_232955_a_(ITag.ITagEntry p_232955_1_, String p_232955_2_)
        {
            return this.func_232954_a_(new ITag.Proxy(p_232955_1_, p_232955_2_));
        }

        public ITag.Builder func_232961_a_(ResourceLocation p_232961_1_, String p_232961_2_)
        {
            return this.func_232955_a_(new ITag.ItemEntry(p_232961_1_), p_232961_2_);
        }

        public ITag.Builder func_232964_b_(ResourceLocation p_232964_1_, String p_232964_2_)
        {
            return this.func_232955_a_(new ITag.TagEntry(p_232964_1_), p_232964_2_);
        }

        public <T> Optional<ITag<T>> func_232959_a_(Function<ResourceLocation, ITag<T>> p_232959_1_, Function<ResourceLocation, T> p_232959_2_)
        {
            ImmutableSet.Builder<T> builder = ImmutableSet.builder();

            for (ITag.Proxy itag$proxy : this.field_232953_a_)
            {
                if (!itag$proxy.func_232968_a_().func_230238_a_(p_232959_1_, p_232959_2_, builder::add))
                {
                    return Optional.empty();
                }
            }

            return Optional.of(ITag.func_232946_a_(builder.build()));
        }

        public Stream<ITag.Proxy> func_232962_b_()
        {
            return this.field_232953_a_.stream();
        }

        public <T> Stream<ITag.Proxy> func_232963_b_(Function<ResourceLocation, ITag<T>> p_232963_1_, Function<ResourceLocation, T> p_232963_2_)
        {
            return this.func_232962_b_().filter((p_232960_2_) ->
            {
                return !p_232960_2_.func_232968_a_().func_230238_a_(p_232963_1_, p_232963_2_, (p_232957_0_) -> {
                });
            });
        }

        public ITag.Builder func_232956_a_(JsonObject p_232956_1_, String p_232956_2_)
        {
            JsonArray jsonarray = JSONUtils.getJsonArray(p_232956_1_, "values");
            List<ITag.ITagEntry> list = Lists.newArrayList();

            for (JsonElement jsonelement : jsonarray)
            {
                String s = JSONUtils.getString(jsonelement, "value");

                if (s.startsWith("#"))
                {
                    list.add(new ITag.TagEntry(new ResourceLocation(s.substring(1))));
                }
                else
                {
                    list.add(new ITag.ItemEntry(new ResourceLocation(s)));
                }
            }

            if (JSONUtils.getBoolean(p_232956_1_, "replace", false))
            {
                this.field_232953_a_.clear();
            }

            list.forEach((p_232958_2_) ->
            {
                this.field_232953_a_.add(new ITag.Proxy(p_232958_2_, p_232956_2_));
            });
            return this;
        }

        public JsonObject func_232965_c_()
        {
            JsonObject jsonobject = new JsonObject();
            JsonArray jsonarray = new JsonArray();

            for (ITag.Proxy itag$proxy : this.field_232953_a_)
            {
                itag$proxy.func_232968_a_().func_230237_a_(jsonarray);
            }

            jsonobject.addProperty("replace", false);
            jsonobject.add("values", jsonarray);
            return jsonobject;
        }
    }

    public interface INamedTag<T> extends ITag<T>
    {
        ResourceLocation func_230234_a_();
    }

    public interface ITagEntry
    {
        <T> boolean func_230238_a_(Function<ResourceLocation, ITag<T>> p_230238_1_, Function<ResourceLocation, T> p_230238_2_, Consumer<T> p_230238_3_);

        void func_230237_a_(JsonArray p_230237_1_);
    }

    public static class ItemEntry implements ITag.ITagEntry
    {
        private final ResourceLocation field_232969_a_;

        public ItemEntry(ResourceLocation p_i1596_1_)
        {
            this.field_232969_a_ = p_i1596_1_;
        }

        public <T> boolean func_230238_a_(Function<ResourceLocation, ITag<T>> p_230238_1_, Function<ResourceLocation, T> p_230238_2_, Consumer<T> p_230238_3_)
        {
            T t = p_230238_2_.apply(this.field_232969_a_);

            if (t == null)
            {
                return false;
            }
            else
            {
                p_230238_3_.accept(t);
                return true;
            }
        }

        public void func_230237_a_(JsonArray p_230237_1_)
        {
            p_230237_1_.add(this.field_232969_a_.toString());
        }

        public String toString()
        {
            return this.field_232969_a_.toString();
        }
    }

    public static class Proxy
    {
        private final ITag.ITagEntry field_232966_a_;
        private final String field_232967_b_;

        private Proxy(ITag.ITagEntry p_i3029_1_, String p_i3029_2_)
        {
            this.field_232966_a_ = p_i3029_1_;
            this.field_232967_b_ = p_i3029_2_;
        }

        public ITag.ITagEntry func_232968_a_()
        {
            return this.field_232966_a_;
        }

        public String toString()
        {
            return this.field_232966_a_.toString() + " (from " + this.field_232967_b_ + ")";
        }
    }

    public static class TagEntry implements ITag.ITagEntry
    {
        private final ResourceLocation id;

        public TagEntry(ResourceLocation p_i3341_1_)
        {
            this.id = p_i3341_1_;
        }

        public <T> boolean func_230238_a_(Function<ResourceLocation, ITag<T>> p_230238_1_, Function<ResourceLocation, T> p_230238_2_, Consumer<T> p_230238_3_)
        {
            ITag<T> itag = p_230238_1_.apply(this.id);

            if (itag == null)
            {
                return false;
            }
            else
            {
                itag.func_230236_b_().forEach(p_230238_3_);
                return true;
            }
        }

        public void func_230237_a_(JsonArray p_230237_1_)
        {
            p_230237_1_.add("#" + this.id);
        }

        public String toString()
        {
            return "#" + this.id;
        }
    }
}
