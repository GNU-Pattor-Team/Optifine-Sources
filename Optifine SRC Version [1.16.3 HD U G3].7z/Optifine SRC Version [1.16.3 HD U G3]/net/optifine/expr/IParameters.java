package net.optifine.expr;

public interface IParameters
{
    ExpressionType[] getParameterTypes(IExpression[] var1);
}
