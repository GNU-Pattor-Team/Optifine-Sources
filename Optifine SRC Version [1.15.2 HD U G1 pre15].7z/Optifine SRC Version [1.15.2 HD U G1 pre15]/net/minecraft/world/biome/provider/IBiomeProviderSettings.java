package net.minecraft.world.biome.provider;

public interface IBiomeProviderSettings
{
}
