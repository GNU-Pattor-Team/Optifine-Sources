package net.optifine.config;

public interface IParserInt
{
    int parse(String var1, int var2);
}
