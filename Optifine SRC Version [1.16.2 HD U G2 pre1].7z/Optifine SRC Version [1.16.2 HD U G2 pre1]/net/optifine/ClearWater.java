package net.optifine;

public class ClearWater
{
}
