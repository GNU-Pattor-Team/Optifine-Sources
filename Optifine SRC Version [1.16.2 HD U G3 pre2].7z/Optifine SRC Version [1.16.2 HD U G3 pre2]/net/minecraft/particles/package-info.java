@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.particles;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;