@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.mojang.blaze3d.vertex;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;