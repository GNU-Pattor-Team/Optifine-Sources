@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.client.renderer.texture;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;