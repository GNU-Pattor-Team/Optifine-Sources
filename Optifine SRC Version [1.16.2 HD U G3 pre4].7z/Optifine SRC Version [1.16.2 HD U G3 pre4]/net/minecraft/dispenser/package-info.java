@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.dispenser;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;