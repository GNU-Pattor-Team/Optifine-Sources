package net.minecraftforge.common.extensions;

public interface IForgePacketBuffer
{
}
