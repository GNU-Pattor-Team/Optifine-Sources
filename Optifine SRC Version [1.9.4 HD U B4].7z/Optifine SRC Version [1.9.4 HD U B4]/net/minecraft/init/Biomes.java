package net.minecraft.init;

import net.minecraft.util.ResourceLocation;
import net.minecraft.world.biome.Biome;

public abstract class Biomes
{
    public static final Biome ocean;
    public static final Biome DEFAULT;
    public static final Biome plains;
    public static final Biome desert;
    public static final Biome extremeHills;
    public static final Biome forest;
    public static final Biome taiga;
    public static final Biome swampland;
    public static final Biome river;
    public static final Biome hell;

    /** Is the biome used for sky world. */
    public static final Biome sky;
    public static final Biome frozenOcean;
    public static final Biome frozenRiver;
    public static final Biome icePlains;
    public static final Biome iceMountains;
    public static final Biome mushroomIsland;
    public static final Biome mushroomIslandShore;

    /** Beach biome. */
    public static final Biome beach;

    /** Desert Hills biome. */
    public static final Biome desertHills;

    /** Forest Hills biome. */
    public static final Biome forestHills;

    /** Taiga Hills biome. */
    public static final Biome taigaHills;

    /** Extreme Hills Edge biome. */
    public static final Biome extremeHillsEdge;

    /** Jungle biome identifier */
    public static final Biome jungle;
    public static final Biome jungleHills;
    public static final Biome jungleEdge;
    public static final Biome deepOcean;
    public static final Biome stoneBeach;
    public static final Biome coldBeach;
    public static final Biome birchForest;
    public static final Biome birchForestHills;
    public static final Biome roofedForest;
    public static final Biome coldTaiga;
    public static final Biome coldTaigaHills;
    public static final Biome megaTaiga;
    public static final Biome megaTaigaHills;
    public static final Biome extremeHillsPlus;
    public static final Biome savanna;
    public static final Biome savannaPlateau;
    public static final Biome mesa;
    public static final Biome mesaPlateau_F;
    public static final Biome mesaPlateau;
    public static final Biome voidBiome;
    public static final Biome mutated_plains;
    public static final Biome mutated_desert;
    public static final Biome mutated_extreme_hills;
    public static final Biome mutated_forest;
    public static final Biome mutated_taiga;
    public static final Biome mutated_swampland;
    public static final Biome mutated_ice_flats;
    public static final Biome mutated_jungle;
    public static final Biome mutated_jungle_edge;
    public static final Biome mutated_birch_forest;
    public static final Biome mutated_birch_forest_hills;
    public static final Biome mutated_roofed_forest;
    public static final Biome mutated_taiga_cold;
    public static final Biome mutated_redwood_taiga;
    public static final Biome mutated_redwood_taiga_hills;
    public static final Biome mutated_extreme_hills_with_trees;
    public static final Biome mutated_savanna;
    public static final Biome mutated_savanna_rock;
    public static final Biome mutated_mesa;
    public static final Biome mutated_mesa_rock;
    public static final Biome mutated_mesa_clear_rock;

    private static Biome getRegisteredBiome(String id)
    {
        Biome biome = (Biome)Biome.biomeRegistry.getObject(new ResourceLocation(id));

        if (biome == null)
        {
            throw new IllegalStateException("Invalid Biome requested: " + id);
        }
        else
        {
            return biome;
        }
    }

    static
    {
        if (!Bootstrap.isRegistered())
        {
            throw new RuntimeException("Accessed Biomes before Bootstrap!");
        }
        else
        {
            ocean = getRegisteredBiome("ocean");
            DEFAULT = ocean;
            plains = getRegisteredBiome("plains");
            desert = getRegisteredBiome("desert");
            extremeHills = getRegisteredBiome("extreme_hills");
            forest = getRegisteredBiome("forest");
            taiga = getRegisteredBiome("taiga");
            swampland = getRegisteredBiome("swampland");
            river = getRegisteredBiome("river");
            hell = getRegisteredBiome("hell");
            sky = getRegisteredBiome("sky");
            frozenOcean = getRegisteredBiome("frozen_ocean");
            frozenRiver = getRegisteredBiome("frozen_river");
            icePlains = getRegisteredBiome("ice_flats");
            iceMountains = getRegisteredBiome("ice_mountains");
            mushroomIsland = getRegisteredBiome("mushroom_island");
            mushroomIslandShore = getRegisteredBiome("mushroom_island_shore");
            beach = getRegisteredBiome("beaches");
            desertHills = getRegisteredBiome("desert_hills");
            forestHills = getRegisteredBiome("forest_hills");
            taigaHills = getRegisteredBiome("taiga_hills");
            extremeHillsEdge = getRegisteredBiome("smaller_extreme_hills");
            jungle = getRegisteredBiome("jungle");
            jungleHills = getRegisteredBiome("jungle_hills");
            jungleEdge = getRegisteredBiome("jungle_edge");
            deepOcean = getRegisteredBiome("deep_ocean");
            stoneBeach = getRegisteredBiome("stone_beach");
            coldBeach = getRegisteredBiome("cold_beach");
            birchForest = getRegisteredBiome("birch_forest");
            birchForestHills = getRegisteredBiome("birch_forest_hills");
            roofedForest = getRegisteredBiome("roofed_forest");
            coldTaiga = getRegisteredBiome("taiga_cold");
            coldTaigaHills = getRegisteredBiome("taiga_cold_hills");
            megaTaiga = getRegisteredBiome("redwood_taiga");
            megaTaigaHills = getRegisteredBiome("redwood_taiga_hills");
            extremeHillsPlus = getRegisteredBiome("extreme_hills_with_trees");
            savanna = getRegisteredBiome("savanna");
            savannaPlateau = getRegisteredBiome("savanna_rock");
            mesa = getRegisteredBiome("mesa");
            mesaPlateau_F = getRegisteredBiome("mesa_rock");
            mesaPlateau = getRegisteredBiome("mesa_clear_rock");
            voidBiome = getRegisteredBiome("void");
            mutated_plains = getRegisteredBiome("mutated_plains");
            mutated_desert = getRegisteredBiome("mutated_desert");
            mutated_extreme_hills = getRegisteredBiome("mutated_extreme_hills");
            mutated_forest = getRegisteredBiome("mutated_forest");
            mutated_taiga = getRegisteredBiome("mutated_taiga");
            mutated_swampland = getRegisteredBiome("mutated_swampland");
            mutated_ice_flats = getRegisteredBiome("mutated_ice_flats");
            mutated_jungle = getRegisteredBiome("mutated_jungle");
            mutated_jungle_edge = getRegisteredBiome("mutated_jungle_edge");
            mutated_birch_forest = getRegisteredBiome("mutated_birch_forest");
            mutated_birch_forest_hills = getRegisteredBiome("mutated_birch_forest_hills");
            mutated_roofed_forest = getRegisteredBiome("mutated_roofed_forest");
            mutated_taiga_cold = getRegisteredBiome("mutated_taiga_cold");
            mutated_redwood_taiga = getRegisteredBiome("mutated_redwood_taiga");
            mutated_redwood_taiga_hills = getRegisteredBiome("mutated_redwood_taiga_hills");
            mutated_extreme_hills_with_trees = getRegisteredBiome("mutated_extreme_hills_with_trees");
            mutated_savanna = getRegisteredBiome("mutated_savanna");
            mutated_savanna_rock = getRegisteredBiome("mutated_savanna_rock");
            mutated_mesa = getRegisteredBiome("mutated_mesa");
            mutated_mesa_rock = getRegisteredBiome("mutated_mesa_rock");
            mutated_mesa_clear_rock = getRegisteredBiome("mutated_mesa_clear_rock");
        }
    }
}
