package net.optifine.expr;

public interface IExpressionCached
{
    void reset();
}
