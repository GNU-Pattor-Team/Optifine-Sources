package net.minecraft.client.resources;

public interface IResourceManagerReloadListener
{
    void onResourceManagerReload(IResourceManager p_110549_1_);
}
