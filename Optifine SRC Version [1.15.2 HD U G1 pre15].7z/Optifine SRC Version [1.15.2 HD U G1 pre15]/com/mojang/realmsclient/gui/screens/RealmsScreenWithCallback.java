package com.mojang.realmsclient.gui.screens;

import net.minecraft.realms.RealmsScreen;

public abstract class RealmsScreenWithCallback<T> extends RealmsScreen
{
    abstract void func_223627_a_(T p_223627_1_);
}
