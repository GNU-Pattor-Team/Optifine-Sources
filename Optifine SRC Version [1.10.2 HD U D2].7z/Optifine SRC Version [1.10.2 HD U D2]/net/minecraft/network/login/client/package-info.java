@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.network.login.client;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;