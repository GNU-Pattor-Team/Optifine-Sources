@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.mojang.realmsclient;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;