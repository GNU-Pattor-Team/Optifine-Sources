package net.minecraft.entity.passive;

public interface IAnimals
{
}
