@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.pathfinding;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;