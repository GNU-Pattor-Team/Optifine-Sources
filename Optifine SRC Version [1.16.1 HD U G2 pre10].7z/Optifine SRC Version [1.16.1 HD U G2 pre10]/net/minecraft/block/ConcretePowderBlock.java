package net.minecraft.block;

import net.minecraft.entity.item.FallingBlockEntity;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;

public class ConcretePowderBlock extends FallingBlock
{
    private final BlockState solidifiedState;

    public ConcretePowderBlock(Block p_i814_1_, AbstractBlock.Properties p_i814_2_)
    {
        super(p_i814_2_);
        this.solidifiedState = p_i814_1_.getDefaultState();
    }

    public void onEndFalling(World worldIn, BlockPos pos, BlockState fallingState, BlockState hitState, FallingBlockEntity p_176502_5_)
    {
        if (func_230137_b_(worldIn, pos, hitState))
        {
            worldIn.setBlockState(pos, this.solidifiedState, 3);
        }
    }

    public BlockState getStateForPlacement(BlockItemUseContext context)
    {
        IBlockReader iblockreader = context.getWorld();
        BlockPos blockpos = context.getPos();
        BlockState blockstate = iblockreader.getBlockState(blockpos);
        return func_230137_b_(iblockreader, blockpos, blockstate) ? this.solidifiedState : super.getStateForPlacement(context);
    }

    private static boolean func_230137_b_(IBlockReader p_230137_0_, BlockPos p_230137_1_, BlockState p_230137_2_)
    {
        return causesSolidify(p_230137_2_) || isTouchingLiquid(p_230137_0_, p_230137_1_);
    }

    private static boolean isTouchingLiquid(IBlockReader p_196441_0_, BlockPos p_196441_1_)
    {
        boolean flag = false;
        BlockPos.Mutable blockpos$mutable = p_196441_1_.func_239590_i_();

        for (Direction direction : Direction.values())
        {
            BlockState blockstate = p_196441_0_.getBlockState(blockpos$mutable);

            if (direction != Direction.DOWN || causesSolidify(blockstate))
            {
                blockpos$mutable.func_239622_a_(p_196441_1_, direction);
                blockstate = p_196441_0_.getBlockState(blockpos$mutable);

                if (causesSolidify(blockstate) && !blockstate.isSolidSide(p_196441_0_, p_196441_1_, direction.getOpposite()))
                {
                    flag = true;
                    break;
                }
            }
        }

        return flag;
    }

    private static boolean causesSolidify(BlockState p_212566_0_)
    {
        return p_212566_0_.getFluidState().isTagged(FluidTags.WATER);
    }

    public BlockState updatePostPlacement(BlockState stateIn, Direction facing, BlockState facingState, IWorld worldIn, BlockPos currentPos, BlockPos facingPos)
    {
        return isTouchingLiquid(worldIn, currentPos) ? this.solidifiedState : super.updatePostPlacement(stateIn, facing, facingState, worldIn, currentPos, facingPos);
    }

    public int getDustColor(BlockState state, IBlockReader p_189876_2_, BlockPos p_189876_3_)
    {
        return state.getMaterialColor(p_189876_2_, p_189876_3_).colorValue;
    }
}
