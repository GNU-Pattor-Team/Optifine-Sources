package net.minecraftforge.common.model;

public interface IModelPart
{
}
