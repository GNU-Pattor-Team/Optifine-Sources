package net.minecraft.util;

public interface IIntArray
{
    int get(int index);

    void set(int index, int value);

    int size();
}
