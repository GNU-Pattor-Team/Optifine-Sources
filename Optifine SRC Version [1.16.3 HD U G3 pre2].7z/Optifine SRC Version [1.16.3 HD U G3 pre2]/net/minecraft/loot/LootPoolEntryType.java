package net.minecraft.loot;

public class LootPoolEntryType extends LootType<LootEntry>
{
    public LootPoolEntryType(ILootSerializer <? extends LootEntry > p_i232168_1_)
    {
        super(p_i232168_1_);
    }
}
