package net.minecraft.entity;

public interface IJumpingMount
{
    void setJumpPower(int jumpPowerIn);

    boolean func_184776_b();

    void func_184775_b(int p_184775_1_);

    void func_184777_r_();
}
