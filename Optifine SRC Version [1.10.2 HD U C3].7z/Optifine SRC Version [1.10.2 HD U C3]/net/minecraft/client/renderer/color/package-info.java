@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.client.renderer.color;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;