package net.minecraft.entity;

public interface IEntityLivingData
{
}
