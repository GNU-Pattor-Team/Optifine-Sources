package net.optifine.reflect;

public interface IResolvable
{
    void resolve();
}
