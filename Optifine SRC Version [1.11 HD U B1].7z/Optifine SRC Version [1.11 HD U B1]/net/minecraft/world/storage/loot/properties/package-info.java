@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.world.storage.loot.properties;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;