@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.test;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;