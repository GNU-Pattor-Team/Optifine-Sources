package net.minecraft.world;

public class MinecraftException extends Exception
{
    public MinecraftException(String msg)
    {
        super(msg);
    }
}
