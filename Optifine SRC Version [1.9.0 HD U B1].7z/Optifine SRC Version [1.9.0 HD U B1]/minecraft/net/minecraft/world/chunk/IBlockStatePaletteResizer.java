package net.minecraft.world.chunk;

import net.minecraft.block.state.IBlockState;

interface IBlockStatePaletteResizer
{
    int func_186008_a(int var1, IBlockState var2);
}
