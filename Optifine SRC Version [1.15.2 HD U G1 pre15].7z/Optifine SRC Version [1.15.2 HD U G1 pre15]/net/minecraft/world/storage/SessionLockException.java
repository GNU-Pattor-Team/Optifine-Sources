package net.minecraft.world.storage;

public class SessionLockException extends Exception
{
    public SessionLockException(String p_i2739_1_)
    {
        super(p_i2739_1_);
    }
}
