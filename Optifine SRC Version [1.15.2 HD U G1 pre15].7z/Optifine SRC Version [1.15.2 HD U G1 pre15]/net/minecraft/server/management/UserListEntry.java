package net.minecraft.server.management;

import com.google.gson.JsonObject;
import javax.annotation.Nullable;

public class UserListEntry<T>
{
    @Nullable
    private final T value;

    public UserListEntry(T p_i2516_1_)
    {
        this.value = p_i2516_1_;
    }

    protected UserListEntry(@Nullable T p_i2517_1_, JsonObject p_i2517_2_)
    {
        this.value = p_i2517_1_;
    }

    @Nullable
    T getValue()
    {
        return this.value;
    }

    boolean hasBanExpired()
    {
        return false;
    }

    protected void onSerialization(JsonObject data)
    {
    }
}
