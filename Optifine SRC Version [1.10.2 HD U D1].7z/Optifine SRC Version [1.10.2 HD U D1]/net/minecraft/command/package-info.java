@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.command;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;