package net.optifine.expr;

public enum ExpressionType
{
    FLOAT,
    FLOAT_ARRAY,
    BOOL;
}
