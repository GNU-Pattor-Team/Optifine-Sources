package net.minecraft.test;

public class TestTrackerHolder
{
    private final TestTracker field_229487_a_;

    public TestTrackerHolder(TestTracker p_i226068_1_)
    {
        this.field_229487_a_ = p_i226068_1_;
    }
}
