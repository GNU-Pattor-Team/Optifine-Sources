package net.optifine.reflect;

import java.lang.reflect.Field;

public interface IFieldLocator
{
    Field getField();
}
