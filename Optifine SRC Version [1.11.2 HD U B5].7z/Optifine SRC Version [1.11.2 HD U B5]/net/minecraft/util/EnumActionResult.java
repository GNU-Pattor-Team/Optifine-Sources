package net.minecraft.util;

public enum EnumActionResult
{
    SUCCESS,
    PASS,
    FAIL;
}
