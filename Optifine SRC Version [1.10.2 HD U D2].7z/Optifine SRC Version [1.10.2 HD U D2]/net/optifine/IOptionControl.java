package net.optifine;

import net.minecraft.client.settings.GameSettings;

public interface IOptionControl
{
    GameSettings.Options getOption();
}
