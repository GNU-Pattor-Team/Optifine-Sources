@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.world.spawner;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;