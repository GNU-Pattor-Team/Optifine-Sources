@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.mojang.realmsclient.util;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;