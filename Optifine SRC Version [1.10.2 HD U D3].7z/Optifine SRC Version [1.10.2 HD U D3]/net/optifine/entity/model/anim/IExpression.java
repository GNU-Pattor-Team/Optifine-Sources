package net.optifine.entity.model.anim;

public interface IExpression
{
    float eval();
}
