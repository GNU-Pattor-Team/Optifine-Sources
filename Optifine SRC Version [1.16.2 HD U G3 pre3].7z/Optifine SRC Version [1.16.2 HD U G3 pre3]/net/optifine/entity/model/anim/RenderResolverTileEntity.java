package net.optifine.entity.model.anim;

import net.optifine.expr.IExpression;

public class RenderResolverTileEntity implements IRenderResolver
{
    public IExpression getParameter(String name)
    {
        return null;
    }
}
