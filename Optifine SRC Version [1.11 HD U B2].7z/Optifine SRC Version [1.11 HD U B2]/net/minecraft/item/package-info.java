@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.item;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;