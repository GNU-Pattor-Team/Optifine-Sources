package net.optifine.util;

import net.minecraft.util.RegistryKey;
import net.minecraft.world.World;

public class WorldUtils
{
    public static final int UNKNOWN_DIMENSION_ID = -2;

    public static int getDimensionId(World world)
    {
        return world == null ? -2 : getDimensionId(world.getDimension());
    }

    public static int getDimensionId(RegistryKey<World> dimension)
    {
        if (dimension == World.NETHER)
        {
            return -1;
        }
        else if (dimension == World.OVERWORLD)
        {
            return 0;
        }
        else
        {
            return dimension == World.THE_END ? 1 : -2;
        }
    }

    public static boolean isNether(World world)
    {
        return world.getDimension() == World.NETHER;
    }

    public static boolean isOverworld(World world)
    {
        return world.getDimension() == World.OVERWORLD;
    }

    public static boolean isEnd(World world)
    {
        return world.getDimension() == World.THE_END;
    }
}
