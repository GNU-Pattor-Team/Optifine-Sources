package optfine;

import net.minecraft.client.settings.GameSettings;

public interface IOptionControl
{
    GameSettings.Options getOption();
}
