package net.minecraft.inventory;

import net.minecraft.util.text.ITextComponent;

public class ContainerHorseChest extends InventoryBasic
{
    public ContainerHorseChest(String p_i47268_1_, int p_i47268_2_)
    {
        super(p_i47268_1_, false, p_i47268_2_);
    }

    public ContainerHorseChest(ITextComponent p_i47269_1_, int p_i47269_2_)
    {
        super(p_i47269_1_, p_i47269_2_);
    }
}
