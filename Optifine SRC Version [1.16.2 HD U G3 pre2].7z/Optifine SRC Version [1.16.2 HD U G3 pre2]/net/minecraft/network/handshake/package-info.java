@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.network.handshake;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;