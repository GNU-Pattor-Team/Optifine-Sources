package com.mojang.realmsclient.gui.screens;

import com.mojang.blaze3d.matrix.MatrixStack;
import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import net.minecraft.client.gui.DialogTexts;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.realms.RealmsNarratorHelper;
import net.minecraft.realms.RealmsScreen;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TranslationTextComponent;

public class RealmsLongConfirmationScreen extends RealmsScreen
{
    private final RealmsLongConfirmationScreen.Type field_224254_e;
    private final ITextComponent field_224255_f;
    private final ITextComponent field_224256_g;
    protected final BooleanConsumer field_237845_a_;
    private final boolean field_224258_i;

    public RealmsLongConfirmationScreen(BooleanConsumer p_i1927_1_, RealmsLongConfirmationScreen.Type p_i1927_2_, ITextComponent p_i1927_3_, ITextComponent p_i1927_4_, boolean p_i1927_5_)
    {
        this.field_237845_a_ = p_i1927_1_;
        this.field_224254_e = p_i1927_2_;
        this.field_224255_f = p_i1927_3_;
        this.field_224256_g = p_i1927_4_;
        this.field_224258_i = p_i1927_5_;
    }

    public void init()
    {
        RealmsNarratorHelper.func_239551_a_(this.field_224254_e.field_225144_d, this.field_224255_f.getString(), this.field_224256_g.getString());

        if (this.field_224258_i)
        {
            this.addButton(new Button(this.width / 2 - 105, func_239562_k_(8), 100, 20, DialogTexts.field_240634_e_, (p_237848_1_) ->
            {
                this.field_237845_a_.accept(true);
            }));
            this.addButton(new Button(this.width / 2 + 5, func_239562_k_(8), 100, 20, DialogTexts.field_240635_f_, (p_237847_1_) ->
            {
                this.field_237845_a_.accept(false);
            }));
        }
        else
        {
            this.addButton(new Button(this.width / 2 - 50, func_239562_k_(8), 100, 20, new TranslationTextComponent("mco.gui.ok"), (p_237846_1_) ->
            {
                this.field_237845_a_.accept(true);
            }));
        }
    }

    public boolean keyPressed(int p_231046_1_, int p_231046_2_, int p_231046_3_)
    {
        if (p_231046_1_ == 256)
        {
            this.field_237845_a_.accept(false);
            return true;
        }
        else
        {
            return super.keyPressed(p_231046_1_, p_231046_2_, p_231046_3_);
        }
    }

    public void render(MatrixStack p_230430_1_, int p_230430_2_, int p_230430_3_, float p_230430_4_)
    {
        this.renderBackground(p_230430_1_);
        this.drawCenteredString(p_230430_1_, this.font, this.field_224254_e.field_225144_d, this.width / 2, func_239562_k_(2), this.field_224254_e.field_225143_c);
        this.drawCenteredString(p_230430_1_, this.font, this.field_224255_f, this.width / 2, func_239562_k_(4), 16777215);
        this.drawCenteredString(p_230430_1_, this.font, this.field_224256_g, this.width / 2, func_239562_k_(6), 16777215);
        super.render(p_230430_1_, p_230430_2_, p_230430_3_, p_230430_4_);
    }

    public static enum Type
    {
        Warning("Warning!", 16711680),
        Info("Info!", 8226750);

        public final int field_225143_c;
        public final String field_225144_d;

        private Type(String p_i303_3_, int p_i303_4_)
        {
            this.field_225144_d = p_i303_3_;
            this.field_225143_c = p_i303_4_;
        }
    }
}
