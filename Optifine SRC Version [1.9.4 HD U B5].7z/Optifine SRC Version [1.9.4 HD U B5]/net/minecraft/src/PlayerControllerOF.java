package net.minecraft.src;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class PlayerControllerOF extends PlayerControllerMP
{
    private boolean acting = false;

    public PlayerControllerOF(Minecraft p_i60_1_, NetHandlerPlayClient p_i60_2_)
    {
        super(p_i60_1_, p_i60_2_);
    }

    /**
     * Called when the player is hitting a block with an item.
     */
    public boolean clickBlock(BlockPos loc, EnumFacing face)
    {
        this.acting = true;
        boolean flag = super.clickBlock(loc, face);
        this.acting = false;
        return flag;
    }

    public boolean onPlayerDamageBlock(BlockPos posBlock, EnumFacing directionFacing)
    {
        this.acting = true;
        boolean flag = super.onPlayerDamageBlock(posBlock, directionFacing);
        this.acting = false;
        return flag;
    }

    public EnumActionResult func_187101_a(EntityPlayer p_187101_1_, World p_187101_2_, ItemStack p_187101_3_, EnumHand p_187101_4_)
    {
        this.acting = true;
        EnumActionResult enumactionresult = super.func_187101_a(p_187101_1_, p_187101_2_, p_187101_3_, p_187101_4_);
        this.acting = false;
        return enumactionresult;
    }

    public EnumActionResult func_187099_a(EntityPlayerSP p_187099_1_, WorldClient p_187099_2_, ItemStack p_187099_3_, BlockPos p_187099_4_, EnumFacing p_187099_5_, Vec3d p_187099_6_, EnumHand p_187099_7_)
    {
        this.acting = true;
        EnumActionResult enumactionresult = super.func_187099_a(p_187099_1_, p_187099_2_, p_187099_3_, p_187099_4_, p_187099_5_, p_187099_6_, p_187099_7_);
        this.acting = false;
        return enumactionresult;
    }

    public boolean isActing()
    {
        return this.acting;
    }
}
