package net.optifine.entity.model;

import net.minecraft.client.model.ModelBase;

public class CustomEntityModel extends ModelBase
{
}
