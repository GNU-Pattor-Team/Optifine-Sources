package net.minecraft.item.crafting;

public enum RecipeBookCategory
{
    CRAFTING,
    FURNACE,
    BLAST_FURNACE,
    SMOKER;
}
