package net.minecraftforge.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.world.ClientWorld;

public interface IRenderHandler
{
    void render(int var1, float var2, ClientWorld var3, Minecraft var4);
}
