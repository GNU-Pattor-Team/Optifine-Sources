package net.minecraft.test;

public class TestTimeoutException extends RuntimeException
{
    public TestTimeoutException(String p_i226071_1_)
    {
        super(p_i226071_1_);
    }
}
