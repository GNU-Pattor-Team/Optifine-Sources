package net.optifine.expr;

public interface IExpressionResolver
{
    IExpression getExpression(String var1);
}
