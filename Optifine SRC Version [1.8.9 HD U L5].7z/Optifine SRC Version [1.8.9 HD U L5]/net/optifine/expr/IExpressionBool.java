package net.optifine.expr;

public interface IExpressionBool extends IExpression
{
    boolean eval();
}
