package net.minecraft.client.renderer.texture;

import net.minecraft.util.IIcon;

public interface IIconRegister
{
    IIcon registerIcon(String p_94245_1_);
}
