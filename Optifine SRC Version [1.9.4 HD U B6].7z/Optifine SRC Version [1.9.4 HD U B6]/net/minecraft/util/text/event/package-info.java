@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.util.text.event;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;