package net.optifine.util;

import net.minecraft.client.renderer.texture.ITickable;
import net.minecraft.client.renderer.texture.Texture;

public abstract class TickableTexture extends Texture implements ITickable
{
}
