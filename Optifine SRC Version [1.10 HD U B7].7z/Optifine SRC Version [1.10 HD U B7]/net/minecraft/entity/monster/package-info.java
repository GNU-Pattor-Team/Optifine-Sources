@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.entity.monster;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;