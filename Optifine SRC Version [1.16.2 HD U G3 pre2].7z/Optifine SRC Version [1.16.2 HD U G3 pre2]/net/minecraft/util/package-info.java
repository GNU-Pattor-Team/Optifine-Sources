@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.util;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;