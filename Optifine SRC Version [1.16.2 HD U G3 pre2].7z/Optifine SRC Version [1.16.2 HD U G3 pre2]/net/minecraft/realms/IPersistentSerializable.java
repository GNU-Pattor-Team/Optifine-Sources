package net.minecraft.realms;

public interface IPersistentSerializable
{
}
