@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.world.gen.structure.template;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;