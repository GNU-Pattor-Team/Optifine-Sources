package net.optifine.gui;

import net.minecraft.client.AbstractOption;

public interface IOptionControl
{
    AbstractOption getControlOption();
}
