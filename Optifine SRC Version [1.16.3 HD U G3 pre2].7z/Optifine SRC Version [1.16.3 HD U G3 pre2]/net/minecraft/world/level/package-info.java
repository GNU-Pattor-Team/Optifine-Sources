@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.world.level;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;